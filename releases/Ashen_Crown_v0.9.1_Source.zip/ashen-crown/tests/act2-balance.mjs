// v0.6 Phase D / v0.6.1 / v0.7.0: M01→M14 legal-policy campaign simulation (30 seeds). M07–M14 must stay winnable (≥ 90%) with
// the choices alternated (M07 deserters handover/legion, M08 order hold/rescue — the rescue runs deploy with the
// 'defense' preset so two heroes start by the rear village); saves round-trip mid-campaign.
import {newGame,startBattle,nextMission,presetDeployment} from '../src/core/game.js';import {playBattle} from './player-policy.mjs';import {playCampaignBattle,setPersuadeFirst} from './campaign-policy.mjs';
import {chooseDeserters,chooseOrder} from '../src/core/mission-rules-v06.js';import {chooseStance} from '../src/core/mission-rules-v061.js';import {chooseOath,chooseRecords} from '../src/core/mission-rules-v070.js';import {serialize,deserialize} from '../src/persistence/save-manager.js';import {chooseRecords15,chooseStones16} from '../src/core/mission-rules-v090.js';import {chooseOath17,chooseTruth18} from '../src/core/mission-rules-v091.js';import {enterHub} from '../src/core/frontier.js';import {startSkirmish} from '../src/core/skirmish.js';import {applyClass} from '../src/core/progression.js';import {CLASS_TREE} from '../src/data/classes.js';import {playSkirmish} from './skirmish-policy.mjs';import {drain} from './campaign-policy.mjs';import fs from 'node:fs';
const N=+process.argv[2]||30,start=+process.argv[3]||20261014,out=[],out3=[],trials=[];
// v0.9.1: a side copy of the camp tries a trial with the policy (forced: the balance party is not promoted along the way);
// the campaign itself goes on unchanged, so M17–M18 numbers are those of the same party as v0.9.0's M15–M16.
function tryTrial(s,hero,seed){if(!s.campaign.heroes?.some(h=>h.id===hero))return;const c=structuredClone(s);c.outcome='victory';enterHub(c,{aftermath:true,story:false});drain(c);const rec=c.campaign.heroes.find(h=>h.id===hero),tier=['eric','elina','sain'].includes(hero)?3:2;
 for(let t=2;t<tier;t++)applyClass(rec,CLASS_TREE[hero].find(k=>k.tier===t));const t=startSkirmish(c,'trial',hero,{force:true});if(!t)return;let r;try{r=playSkirmish(t);}catch(e){r={outcome:'ERR '+e.message};}deserialize(serialize(t));trials.push({seed,hero,tier,mission:t.missionId,level:rec.level,outcome:t.outcome,turn:t.turn,why:t.reason});}
for(let seed=start;seed<start+N;seed++){let s=newGame(seed);s.screen='deployment';startBattle(s);playBattle(s);
 for(const id of [2,3,4,5,6]){s=nextMission(s);if(id===5)s.campaign.choices.m05_erik_answer=seed%2?'present':'acknowledged';s.screen='deployment';startBattle(s);playCampaignBattle(s,id===2?seed%2===0:true);if(s.outcome!=='victory')break;if(id===4)s.campaign.choices.m04_records_choice=seed%2?'kept':'reported';}
 if(s.outcome!=='victory'){out.push({seed,stop:s.missionId,outcome:s.outcome});continue;}
 s.campaign.choices.m06_oath=['people','comrades','truth'][seed%3];const r={seed,records:s.campaign.choices.m04_records_choice};
 s=nextMission(s);r.lv=s.units.filter(u=>u.team==='ally').map(u=>`${u.id}${u.level}`).join(' ');s.screen='deployment';startBattle(s);let p;try{p=playCampaignBattle(s);}catch(e){p={outcome:'ERR '+e.message};}deserialize(serialize(s));
 Object.assign(r,{m7:p.outcome,t7:s.turn,why7:s.reason,escorts:s.units.filter(u=>u.team==='allied'&&u.hp>0).length,through:s.units.filter(w=>w.kind==='wagon'&&w.rescued).length,captured:s.missionState.captured});
 if(s.outcome!=='victory'){r.feats=[...(s.campaign.feats||[])];out.push(r);continue;}
 if(s.missionState.captured){chooseDeserters(s,seed%3===0?'handover':'legion');r.deserters=s.campaign.choices.m07_deserters;}
 s=nextMission(s);chooseOrder(s,seed%2?'rescue':'hold');s.screen='deployment';if(seed%2)presetDeployment(s,'defense');startBattle(s);try{p=playCampaignBattle(s);}catch(e){p={outcome:'ERR '+e.message};}deserialize(serialize(s));
 Object.assign(r,{m8:p.outcome,t8:s.turn,why8:s.reason,order:s.campaign.choices.m08_order,saved:s.units.filter(v=>v.team==='civilian'&&v.rescued).length,rockfalls:s.missionState.rockfall.length,iron:s.campaign.factionTrust?.iron,thea:!!s.campaign.roster?.includes('thea')});
 if(s.outcome!=='victory'){r.feats=[...(s.campaign.feats||[])];out.push(r);continue;}
 // v0.6.1: M09 (Velmar) and M10 (stance rotated by seed: support Oswin / support Brennan / mediate).
 s=nextMission(s);s.screen='deployment';startBattle(s);try{p=playCampaignBattle(s);}catch(e){p={outcome:'ERR '+e.message};}deserialize(serialize(s));
 Object.assign(r,{m9:p.outcome,t9:s.turn,why9:s.reason,delegates:s.units.filter(v=>v.team==='civilian'&&v.hp>0).length,captured9:!!s.missionState.captured});
 if(s.outcome!=='victory'){r.feats=[...(s.campaign.feats||[])];out.push(r);continue;}
 s=nextMission(s);s.screen='deployment';chooseStance(s,['a','b','mediate'][seed%3]);startBattle(s);try{p=playCampaignBattle(s);}catch(e){p={outcome:'ERR '+e.message};}deserialize(serialize(s));
 Object.assign(r,{m10:p.outcome,t10:s.turn,why10:s.reason,stance:s.campaign.choices.m10_stance,mediated:!!s.campaign.flags.mission_10_mediated,villagers10:s.units.filter(v=>v.team==='civilian'&&v.rescued).length,free:s.campaign.factionTrust?.free,dario:!!s.campaign.roster?.includes('dario')});
 if(s.outcome!=='victory'){r.feats=[...(s.campaign.feats||[])];out.push(r);continue;}
 // v0.7.0: M11 (night procession; oath alternated) and M12 (stealth; records: copy when possible, else return/take by seed).
 s=nextMission(s);s.screen='deployment';startBattle(s);try{p=playCampaignBattle(s);}catch(e){p={outcome:'ERR '+e.message};}deserialize(serialize(s));
 Object.assign(r,{m11:p.outcome,t11:s.turn,why11:s.reason,arrived:s.units.filter(v=>v.team==='civilian'&&v.rescued).length,lost11:s.units.filter(v=>v.team==='civilian'&&v.hp<=0).length,lit:s.missionState.lit?.length});
 if(s.outcome!=='victory'){r.feats=[...(s.campaign.feats||[])];out.push(r);continue;}chooseOath(s,seed%2?'oath':'legion');r.oath=s.campaign.choices.m11_oath;
 s=nextMission(s);s.screen='deployment';startBattle(s);try{p=playCampaignBattle(s);}catch(e){p={outcome:'ERR '+e.message};}deserialize(serialize(s));
 Object.assign(r,{m12:p.outcome,t12:s.turn,why12:s.reason,alarm12:s.missionState.alarmTurn,quiet:!!s.missionState.quiet,records:s.units.filter(o=>o.kind==='evidence'&&o.rescued&&!o.burned).length,abbot:!!s.missionState.captured});
 if(s.outcome==='victory'){chooseRecords(s,s.campaign.flags.mission_12_copy_ready?'copy':['return','take'][seed%2]);Object.assign(r,{records12:s.campaign.choices.m12_records,flame:s.campaign.factionTrust?.flame,ines:!!s.campaign.roster?.includes('ines')});deserialize(serialize(s));}
 if(s.outcome!=='victory'){r.feats=[...(s.campaign.feats||[])];out.push(r);continue;}
 // v0.7.1: M13 (even seeds play a persuasion run that spares Baldrick) and M14 (the summit, betrayal by the lowest trust).
 s=nextMission(s);s.screen='deployment';startBattle(s);r.resolve0=s.missionState.resolve;setPersuadeFirst(seed%2===0);try{p=playCampaignBattle(s);}catch(e){p={outcome:'ERR '+e.message};}setPersuadeFirst(false);deserialize(serialize(s));
 Object.assign(r,{m13:p.outcome,t13:s.turn,why13:s.reason,resolve:s.missionState.resolve,baldrick:s.missionState.halted?'halted':s.missionState.withdrew,refugees13:s.units.filter(v=>v.team==='civilian'&&v.hp>0).length});
 if(s.outcome!=='victory'){r.feats=[...(s.campaign.feats||[])];out.push(r);continue;}
 s=nextMission(s);s.screen='deployment';startBattle(s);try{p=playCampaignBattle(s);}catch(e){p={outcome:'ERR '+e.message};}deserialize(serialize(s));
 Object.assign(r,{m14:p.outcome,t14:s.turn,why14:s.reason,betrayer:s.missionState.betrayer,arrived14:s.missionState.arrived.length,recruit14:s.campaign.flags.mission_14_recruit,departed:Object.keys(s.campaign.departed||{}).join('+'),trust14:s.campaign.factionTrust});
 r.feats=[...(s.campaign.feats||[])];out.push(r);
 // v0.9.0 ACT III part 1 (D-079): the campaigns that finish ACT II go on to M15–M16 (records choice and stones alternated).
 // Written to test-output/act3-balance.json so act2-balance.json stays comparable with earlier evidence.
 if(p.outcome!=='victory')continue;const a={seed,lv:s.units.filter(u=>u.team==='ally').map(u=>`${u.id}${u.level}`).join(' '),departed:Object.keys(s.campaign.departed||{}).join('+'),inesIn:!!s.campaign.roster?.includes('ines')};
 s=nextMission(s);s.screen='deployment';startBattle(s);try{p=playCampaignBattle(s);}catch(e){p={outcome:'ERR '+e.message};}deserialize(serialize(s));
 Object.assign(a,{m15:p.outcome,t15:s.turn,why15:s.reason,boxes:s.missionState.secured?.length,watch:s.missionState.turned?'turned':s.missionState.warned?'warned':'calm'});
 if(p.outcome==='victory'){chooseRecords15(s,['archivist','keep','post'][seed%3]);s=nextMission(s);s.screen='deployment';startBattle(s);try{p=playCampaignBattle(s);}catch(e){p={outcome:'ERR '+e.message};}deserialize(serialize(s));
  Object.assign(a,{m16:p.outcome,t16:s.turn,why16:s.reason,echoes:s.missionState.searched?.length,duel:s.duel?.result||'none',returning:s.missionState.returning.join('+'),rejoined:s.missionState.returning.filter(id=>s.campaign.roster?.includes(id)).join('+')});
  if(p.outcome==='victory'){chooseStones16(s,seed%2?'break':'leave');for(const h of ['elina','thea','dario','ines'])tryTrial(s,h,seed);
   // v0.9.1 ACT III part 2 (D-084): M17 then M18 (oath book and truth alternated).
   s=nextMission(s);s.screen='deployment';startBattle(s);try{p=playCampaignBattle(s);}catch(e){p={outcome:'ERR '+e.message};}deserialize(serialize(s));
   Object.assign(a,{m17:p.outcome,t17:s.turn,why17:s.reason,sworn:s.missionState.sworn?.length,claimed:s.missionState.claimed?.length,archive:s.missionState.heldMax});
   if(p.outcome==='victory'){chooseOath17(s,seed%2?'take':'leave');tryTrial(s,'eric',seed);s=nextMission(s);s.screen='deployment';startBattle(s);try{p=playCampaignBattle(s);}catch(e){p={outcome:'ERR '+e.message};}deserialize(serialize(s));
    Object.assign(a,{m18:p.outcome,t18:s.turn,why18:s.reason,trees:s.units.filter(t=>t.kind==='wardTree'&&t.hp>0).length,keepers:s.missionState.sheltered?.length});
    if(p.outcome==='victory'){chooseTruth18(s,seed%2?'tell':'keep');tryTrial(s,'sain',seed);}}}}
 a.feats=[...(s.campaign.feats||[])].filter(id=>id>=15);out3.push(a);}
// v0.8.1: hidden objectives the policy won along the way (it never aims at them) — for the play-test notes, not a gate.
for(const o of out)o.feats=o.feats||[];
for(const o of out)console.log(JSON.stringify(o));
const w7=out.filter(o=>o.m7==='victory'),w8=out.filter(o=>o.m8==='victory'),w9=out.filter(o=>o.m9==='victory'),w10=out.filter(o=>o.m10==='victory'),w11=out.filter(o=>o.m11==='victory'),w12=out.filter(o=>o.m12==='victory'),w13=out.filter(o=>o.m13==='victory'),w14=out.filter(o=>o.m14==='victory');
const featRate=Object.fromEntries(Array.from({length:14},(_,i)=>[`M${i+1}`,out.filter(o=>o.feats.includes(i+1)).length]));
const summary={seeds:out.length,featRate,m7Wins:w7.length,m8Wins:w8.length,m7Turns:w7.map(o=>o.t7),m8Turns:w8.map(o=>o.t8),theaJoined:out.filter(o=>o.thea).length,captured:out.filter(o=>o.captured).length,fullConvoy:out.filter(o=>o.through===3).length,rescueSaved:out.filter(o=>o.order==='rescue').map(o=>o.saved),m9Wins:w9.length,m9Turns:w9.map(o=>o.t9),delegatesAll:out.filter(o=>o.delegates===3).length,captured9:out.filter(o=>o.captured9).length,m10Wins:w10.length,m10ByStance:Object.fromEntries(['a','b','mediate'].map(k=>[k,{runs:out.filter(o=>o.stance===k).length,wins:w10.filter(o=>o.stance===k).length,turns:w10.filter(o=>o.stance===k).map(o=>o.t10)}])),mediated:out.filter(o=>o.mediated).length,villagers10All:out.filter(o=>o.villagers10===3).length,darioJoined:out.filter(o=>o.dario).length,m11Wins:w11.length,m11Turns:w11.map(o=>o.t11),pilgrimsAll:out.filter(o=>o.arrived===4).length,braziersAll:out.filter(o=>o.lit===3).length,m12Wins:w12.length,m12Turns:w12.map(o=>o.t12),quietLedger:w12.filter(o=>o.quiet).length,abbotCaptured:w12.filter(o=>o.abbot).length,records12:Object.fromEntries(['return','take','copy'].map(k=>[k,out.filter(o=>o.records12===k).length])),inesJoined:out.filter(o=>o.ines).length,m13Wins:w13.length,m13Turns:w13.map(o=>o.t13),baldrick:Object.fromEntries(['halted','broken','held'].map(k=>[k,w13.filter(o=>o.baldrick===k).length])),refugees13All:w13.filter(o=>o.refugees13===4).length,m14Wins:w14.length,m14Turns:w14.map(o=>o.t14),betrayer:Object.fromEntries(['iron','free','flame'].map(k=>[k,out.filter(o=>o.betrayer===k).length])),recruit14:Object.fromEntries(['stayed','left','none'].map(k=>[k,w14.filter(o=>o.recruit14===k).length]))};
console.log(JSON.stringify(summary));fs.mkdirSync('test-output',{recursive:true});fs.writeFileSync('test-output/act2-balance.json',JSON.stringify({summary,runs:out},null,1));
const w15=out3.filter(o=>o.m15==='victory'),w16=out3.filter(o=>o.m16==='victory');const w17=out3.filter(o=>o.m17==='victory'),w18=out3.filter(o=>o.m18==='victory');
const summary3={campaigns:out3.length,m15Wins:w15.length,m15Turns:w15.map(o=>o.t15),boxes:Object.fromEntries([2,3].map(n=>[n,w15.filter(o=>o.boxes===n).length])),watch:Object.fromEntries(['calm','warned','turned'].map(k=>[k,out3.filter(o=>o.watch===k).length])),
 m16Wins:w16.length,m16Turns:w16.map(o=>o.t16),echoesAll:w16.filter(o=>o.echoes===3).length,duel:Object.fromEntries(['hero','foe','skipped','none'].map(k=>[k,out3.filter(o=>o.duel===k).length])),returned:out3.filter(o=>o.returning).length,rejoined:out3.filter(o=>o.rejoined).length,featRate:{M15:out3.filter(o=>o.feats.includes(15)).length,M16:out3.filter(o=>o.feats.includes(16)).length,M17:out3.filter(o=>o.feats.includes(17)).length,M18:out3.filter(o=>o.feats.includes(18)).length},
 m17Wins:w17.length,m17Turns:w17.map(o=>o.t17),swornAll:w17.filter(o=>o.sworn===4).length,claimedAny:out3.filter(o=>o.claimed>0).length,archiveTouched:w17.filter(o=>o.archive>0).length,
 m18Wins:w18.length,m18Turns:w18.map(o=>o.t18),treesAll:w18.filter(o=>o.trees===3).length,keepersAll:w18.filter(o=>o.keepers===6).length,
 trials:Object.fromEntries(['elina','eric','sain','thea','dario','ines'].map(h=>{const t=trials.filter(x=>x.hero===h);return [h,{runs:t.length,wins:t.filter(x=>x.outcome==='victory').length,levels:[...new Set(t.map(x=>x.level))].sort((a,b)=>a-b)}];}))};
for(const o of out3)console.log(JSON.stringify(o));console.log(JSON.stringify(summary3));fs.writeFileSync('test-output/act3-balance.json',JSON.stringify({summary:summary3,runs:out3,trials},null,1));
if(w15.length<out3.length*0.9||w16.length<w15.length*0.9||w17.length<w16.length*0.9||w18.length<w17.length*0.9)process.exit(1);
if(w7.length<out.length*0.9||w8.length<w7.length*0.9||w9.length<w8.length*0.9||w10.length<w9.length*0.9||w11.length<w10.length*0.9||w12.length<w11.length*0.9||w13.length<w12.length*0.9||w14.length<w13.length*0.9)process.exit(1);
