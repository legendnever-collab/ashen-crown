# Next Tasks
1. v0.6.1 The Three Banners: the user approved merging the release candidate in chat on 2026-10-26 20:22 KST. After the merge, record the PR number, hosted CI run and merge SHA (docs/v0.6.1/RELEASE_NOTES.md, GitHub); publish tag v0.6.1 and the GitHub Release only when the user asks (a one-time Actions workflow, as for v0.5.0 and v0.6.0, because the session cannot push tags).
2. Play-test watch items: M09 delegates (the legal policy saves all three in every seed), M10 stance balance (support 5–8 turns, mediation 7), Dario joins in every policy run, M07 convoy pacing, D-045 level-relative EXP (PROPOSED) — adjust only with the user's feedback.
3. Next: v0.7.0 ACT II part 2 — M11 성화의 행렬, M12 침묵의 수도원, M13 검은 사자의 결단, M14 부서진 동맹 (Order of the Sacred Flame, Sain's past, Baldrick's decision); design and approval questions first; awakening (Tier 3) only on the user's instruction.
4. Physical phones, other browser engines and long-term storage eviction remain unverified.
