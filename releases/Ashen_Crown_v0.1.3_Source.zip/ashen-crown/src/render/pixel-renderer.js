import {MAP,WIDTH,HEIGHT} from '../data/game-data.js';
import {alive,movement,validTarget} from '../core/rules.js';
import {TILE,drawTile,drawSprite,pixel,pixelOval} from './art.js';
import {RANGE_STYLE,moveDuration,motionAt,presentationPlan} from './animation.js';
import {drawCombatEffect,effectPhase} from './combat-effects.js';
const rect=pixel;
export class BattleRenderer{
 constructor(canvas,getState,getUI){this.canvas=canvas;this.ctx=canvas.getContext('2d');this.getState=getState;this.getUI=getUI;this.zoom=1;this.pan={x:0,y:0};this.camera={scale:1,x:0,y:0};this.effects=[];this.motion=new Map();this.frame=0;this.terrainCanvas=document.createElement('canvas');this.terrainCanvas.width=WIDTH*TILE;this.terrainCanvas.height=HEIGHT*TILE;const tc=this.terrainCanvas.getContext('2d');for(let y=0;y<HEIGHT;y++)for(let x=0;x<WIDTH;x++)drawTile(tc,MAP[y][x],x*TILE,y*TILE,y*WIDTH+x);this.resize();this.observer=new ResizeObserver(()=>this.resize());this.observer.observe(canvas);this.tick=this.tick.bind(this);requestAnimationFrame(this.tick);}
 resize(){const b=this.canvas.getBoundingClientRect(),dpr=window.devicePixelRatio||1;this.canvas.width=Math.round(b.width*dpr);this.canvas.height=Math.round(b.height*dpr);this.dpr=dpr;this.w=b.width;this.h=b.height;this.ctx.imageSmoothingEnabled=false;}
 clearPresentation(){this.effects=[];this.motion.clear();this.hpStart=null;this.hpEvents=[];this.visualUntil=0;this.lastWalk=null;this.lastPresentation=[];}
 reset(){this.zoom=1;this.pan={x:0,y:0};}
 zoomBy(n){this.zoom=Math.max(.7,Math.min(2.4,this.zoom*n));this.clampPan();}
 clampPan(){this.pan.x=Math.max(-this.w*.6,Math.min(this.w*.6,this.pan.x));this.pan.y=Math.max(-this.h*.6,Math.min(this.h*.6,this.pan.y));}
 tileAt(px,py){const {scale,x,y}=this.camera;return {x:Math.floor((px-x)/scale/TILE),y:Math.floor((py-y)/scale/TILE)};}
 tileCenter(x,y){return {x:this.camera.x+(x+.5)*TILE*this.camera.scale,y:this.camera.y+(y+.5)*TILE*this.camera.scale};}
 ranges(){const s=this.getState(),ui=this.getUI(),u=s.units.find(u=>u.id===ui.selected);if(s.screen==='deployment'&&ui.mode==='deploy')return Array.from({length:30},(_,i)=>({x:1+i%10,y:7+Math.floor(i/10)}));if(s.screen!=='battle'||s.phase!=='player'||!u||!alive(u)||u.acted||ui.busy)return [];if(ui.mode==='move'&&!u.moved)return [...movement(s,u).costs.keys()].map(p=>{const [x,y]=p.split(',').map(Number);return {x,y};});if(!['attack','skill','rescue'].includes(ui.mode))return [];const cells=[];for(let y=0;y<HEIGHT;y++)for(let x=0;x<WIDTH;x++){const dummy={x,y,hp:1,team:ui.mode==='skill'&&['sain','eric'].includes(u.id)?'ally':ui.mode==='rescue'?'civilian':'enemy',id:'preview'};if(validTarget(s,u,dummy,ui.mode))cells.push({x,y});}return cells;}
 walk(id,path,movement='step',speed=1){const duration=moveDuration(path,movement,speed);this.lastWalk={id,path:structuredClone(path),movement,speed,duration};if(duration)this.motion.set(id,{path,start:performance.now(),duration,movement,speed});else this.motion.delete(id);return duration;}
 displayHP(u,now=performance.now()){if(!this.hpStart||now>=this.visualUntil)return u.hp;let hp=this.hpStart.get(u.id)??u.hp;for(const e of this.hpEvents||[])if(e.id===u.id&&now>=e.at)hp=e.hp;return hp;}
 addEffects(events,before,settings){const now=performance.now(),plan=presentationPlan(events,this.getState().units,settings);this.hpStart=new Map(before.units.map(u=>[u.id,u.hp]));this.hpEvents=plan.hp.map(e=>({...e,at:now+e.delay}));this.visualUntil=now+plan.duration;this.reduced=settings.reduced;this.effects=plan.plans.map(e=>({...e,start:now+e.delay}));this.lastPresentation=plan.plans.filter(e=>e.type==='attack').map(e=>({id:e.id,target:e.target,kind:e.kind,counter:!!e.counter}));for(const m of plan.motions)this.motion.set(m.id,{...m,start:now+m.delay});return plan.duration;}
 diagnostics(now=performance.now()){return {motion:[...this.motion].map(([id,m])=>({id,...motionAt(m.path,now-m.start,m.movement,m.speed)})),active:this.effects.filter(e=>now>=e.start&&now<e.start+e.duration).map(e=>({type:e.type,kind:e.kind,phase:e.kind?effectPhase(e,now):'feedback',id:e.id,target:e.target})),lastWalk:this.lastWalk||null,lastPresentation:this.lastPresentation||[],rangeStyle:RANGE_STYLE};}
 tick(now){this.draw(now);requestAnimationFrame(this.tick);}
 draw(now){const c=this.ctx,s=this.getState(),ui=this.getUI();if(!s)return;c.setTransform(this.dpr,0,0,this.dpr,0,0);c.clearRect(0,0,this.w,this.h);rect(c,'#172b2b',0,0,this.w,this.h);
  const top=this.w>720?34:8,bottom=30,usable=Math.max(1,this.h-top-bottom);const scale=Math.min((this.w-16)/(WIDTH*TILE),usable/(HEIGHT*TILE))*this.zoom,x=(this.w-WIDTH*TILE*scale)/2+this.pan.x,y=top+(usable-HEIGHT*TILE*scale)/2+this.pan.y;this.camera={scale,x,y};c.translate(Math.round(x),Math.round(y));c.scale(scale,scale);c.imageSmoothingEnabled=false;
  c.drawImage(this.terrainCanvas,0,0);
  const selected=s.units.find(u=>u.id===ui.selected),deploy=s.screen==='deployment';
  if(deploy&&ui.mode==='deploy'){for(let ty=7;ty<10;ty++)for(let tx=1;tx<11;tx++){rect(c,RANGE_STYLE.move.fill,tx*TILE,ty*TILE,TILE,TILE);rect(c,RANGE_STYLE.move.border,tx*TILE,ty*TILE,TILE,2);}}
  if(s.screen==='battle'&&s.phase==='player'&&selected&&alive(selected)&&!selected.acted&&!ui.busy){
   if(ui.mode==='move'&&!selected.moved)for(const p of movement(s,selected).costs.keys()){const [tx,ty]=p.split(',').map(Number);rect(c,RANGE_STYLE.move.fill,tx*TILE+1,ty*TILE+1,60,60);rect(c,RANGE_STYLE.move.border,tx*TILE+1,ty*TILE+1,60,2);}
   else if(['attack','skill','rescue'].includes(ui.mode))for(let ty=0;ty<HEIGHT;ty++)for(let tx=0;tx<WIDTH;tx++){const dummy={x:tx,y:ty,hp:1,team:ui.mode==='skill'&&['sain','eric'].includes(selected.id)?'ally':ui.mode==='rescue'?'civilian':'enemy',id:'preview'};if(validTarget(s,selected,dummy,ui.mode)){rect(c,ui.mode==='rescue'||selected.id==='sain'&&ui.mode==='skill'?RANGE_STYLE.support.fill:RANGE_STYLE.attack.fill,tx*TILE+1,ty*TILE+1,60,60);}}
  }
  if(s.turn===2&&s.screen==='battle')for(const tx of [0,11]){rect(c,'#e1af63',tx*TILE,0,TILE,3);rect(c,'#e1af63',tx*TILE,0,3,TILE);c.fillStyle='#ffdb87';c.font='bold 24px monospace';c.fillText('!',tx*TILE+28,34);}
  const actors=s.units.filter(u=>(alive(u)||this.displayHP(u,now)>0)&&!u.rescued).sort((a,b)=>a.y-b.y);for(const u of actors){let ux=u.x*TILE+32,uy=u.y*TILE+37,pose='idle';const m=this.motion.get(u.id);if(m){const p=motionAt(m.path,now-m.start,m.movement,m.speed);ux=p.x*TILE+32;uy=p.y*TILE+37;pose=p.done?'idle':'walk';if(p.done&&!ui.pendingMove)this.motion.delete(u.id);}else if(ui.pendingMove?.id===u.id){ux=ui.pendingMove.x*TILE+32;uy=ui.pendingMove.y*TILE+37;}
   const effects=this.effects.filter(e=>e.id===u.id&&now>=e.start&&now-e.start<e.duration);if(effects.some(e=>e.type==='attack'))pose='attack';
   if(u.team==='ally'&&u.acted&&s.screen==='battle')c.globalAlpha=.5;
   rect(c,u.team==='ally'?'#72aabb':u.team==='enemy'?'#b15d56':'#ddc28b',ux-18,uy+24,36,3);
   if(ui.selected===u.id){c.strokeStyle='#fff0b8';c.lineWidth=2;c.strokeRect(ux-31,uy-36,60,60);rect(c,'#f4d695',ux-4,uy-37,8,4);}
   drawSprite(c,u,ux,uy,now,pose);c.globalAlpha=1;
   if(u.team!=='civilian'||u.hp<u.maxHP){rect(c,'#18242a',ux-23,uy-31,46,5);rect(c,u.team==='enemy'?'#cc7770':'#99c691',ux-22,uy-30,Math.max(1,Math.floor(44*this.displayHP(u,now)/u.maxHP)),3);}
   if(effects.some(e=>['hit','critical'].includes(e.type))&&Math.floor(now/70)%2){rect(c,'rgba(255,224,192,.5)',ux-22,uy-25,40,47);}
  }
  if(ui.pendingMove){for(const [i,p] of ui.pendingMove.path.entries()){rect(c,i===ui.pendingMove.path.length-1?'#ffe5a0':'#d2ebdf',p.x*TILE+28,p.y*TILE+29,8,5);}c.strokeStyle='#ffe0a2';c.lineWidth=3;c.strokeRect(ui.pendingMove.x*TILE+2,ui.pendingMove.y*TILE+2,60,60);}
  if(ui.hover&&ui.hover.x>=0&&ui.hover.x<12&&ui.hover.y>=0&&ui.hover.y<10){c.strokeStyle='#e4ddbd';c.lineWidth=2;c.strokeRect(ui.hover.x*TILE+1,ui.hover.y*TILE+1,60,60);}
  this.effects=this.effects.filter(e=>now<e.start+e.duration);for(const e of this.effects){const u=s.units.find(u=>u.id===e.id);if(!u||now<e.start||e.type==='move')continue;if(e.type==='attack'){drawCombatEffect(c,e,s.units,now,this.reduced);continue;}const age=(now-e.start)/e.duration;if(e.type==='heal'||e.type==='guard'){const radius=8+age*22;pixelOval(c,e.type==='heal'?'rgba(147,219,164,.35)':'rgba(151,205,237,.35)',u.x*TILE+32,u.y*TILE+32,radius,radius/2);}if(e.type==='death'){drawSprite(c,u,u.x*TILE+32,u.y*TILE+39,now,'death');}
   c.font=`bold ${e.type==='potential'?16:20}px monospace`;c.textAlign='center';c.fillStyle=e.type==='heal'?'#bdedac':e.type==='level'||e.type==='potential'?'#ffe4a0':e.type==='xp'?'#b4dfe3':'#fff1d2';c.strokeStyle='#172a30';c.lineWidth=2;const py=u.y*TILE-3-age*32-(e.type==='xp'?22:0);c.strokeText(e.text||'',u.x*TILE+32,py);c.fillText(e.text||'',u.x*TILE+32,py);c.textAlign='start';}if(this.onCamera)this.onCamera();
 }
}
