import {legacyRewardCatchup} from '../core/battle-rewards.js';
import {ensureEconomy,validateEconomy} from '../core/economy.js';
import {validDuel} from '../core/duel.js';
import {COMMANDS} from '../core/command.js';
import {migrateFrontier,frontierState,validateFrontier,alignFrontier} from '../core/frontier.js';
import {SCHEMA,VERSION,WIDTH,HEIGHT,HEROES,ENEMIES,REINFORCEMENTS,CIVILIANS,ALL_HEROES,RECRUIT_HEROES,partyIds} from '../data/game-data.js';
import {validTrust} from '../core/factions.js';
import {terrainAt,alive} from '../core/rules.js';
import {MISSIONS,missionOf} from '../data/missions.js';
import {maxUnits,missionUnitIds,rulesOf} from '../core/mission-rules.js';
import {STORY} from '../data/story.js';
import {narrativeState} from '../core/narrative.js';
import {validStatus} from '../core/status.js';
import {THROW_LIMIT} from '../core/tactics.js';
import {TOOLS} from '../data/frontier-data.js';
export const SAVE_KEY='ashen-crown:v1',BACKUP_KEY='ashen-crown:last-good';
export function checksum(text){let h=2166136261;for(let i=0;i<text.length;i++){h^=text.charCodeAt(i);h=Math.imul(h,16777619);}return (h>>>0).toString(16);}
export function validate(s){
 if(!s||s.schema!==SCHEMA||!['title','intro','exploration','warroom','deployment','battle','result'].includes(s.screen)||!['player','enemy'].includes(s.phase))throw Error('지원하지 않는 저장 형식입니다.');
 if(!Number.isInteger(s.turn)||s.turn<1||s.turn>10000||!Number.isInteger(s.rng)||s.rng<0||s.rng>4294967295)throw Error('턴 또는 RNG 상태가 손상되었습니다.');
 if(!Array.isArray(s.units)||s.units.length<10||s.units.length>(MISSIONS[s.missionId]?Math.max(14,maxUnits(MISSIONS[s.missionId])):14)||!Array.isArray(s.log)||!s.campaign||!Array.isArray(s.campaign.results)||!Number.isInteger(s.campaign.clears)||!Array.isArray(s.missionStart))throw Error('필수 게임 기록이 없습니다.');
 if(!MISSIONS[s.missionId]||typeof s.practice!=='boolean')throw Error('Mission 기록이 손상되었습니다.');
 const mission=missionOf(s),party=partyIds(s.campaign),allies=mission.allies||[];
 if(s.campaign.roster!=null&&(!Array.isArray(s.campaign.roster)||s.campaign.roster.length>RECRUIT_HEROES.length||new Set(s.campaign.roster).size!==s.campaign.roster.length||s.campaign.roster.some(id=>!RECRUIT_HEROES.some(h=>h.id===id))))throw Error('군단 합류 기록이 손상되었습니다.');
 // v0.7.1 (D-071): a recruit who left after M14 is kept aside until ACT III, never also in the roster.
 if(s.campaign.departed!=null&&(typeof s.campaign.departed!=='object'||Array.isArray(s.campaign.departed)||Object.keys(s.campaign.departed).some(id=>!RECRUIT_HEROES.some(h=>h.id===id)||s.campaign.roster?.includes(id)||s.campaign.departed[id]?.id!==id)))throw Error('군단 이탈 기록이 손상되었습니다.');
 if(!validTrust(s.campaign))throw Error('세력 신뢰 기록이 손상되었습니다.');
 const known=new Set([...party,...missionUnitIds(mission),...allies.map(a=>a.id)]),ids=new Set(),occupied=new Set();
 for(const u of s.units){if(!known.has(u.id)||ids.has(u.id)||!['ally','allied','enemy','civilian','object'].includes(u.team))throw Error('장수 목록이 손상되었습니다.');ids.add(u.id);
  const expected=party.includes(u.id)?'ally':allies.some(a=>a.id===u.id)?(u.betrayed&&s.missionState?.betrayer===u.faction?'enemy':'allied'):mission.civilians.some(c=>c.id===u.id)?(u.turned?'enemy':'civilian'):(mission.objects||[]).some(o=>o.id===u.id)?(u.woke==='ally'?'allied':u.woke==='enemy'?'enemy':'object'):u.faction&&u.faction===s.campaign?.choices?.m10_stance?'allied':'enemy';if(u.team!==expected||typeof u.name!=='string'||u.name.length>120||!Array.isArray(u.range)||u.range.length!==2||u.range.some(n=>!Number.isInteger(n)||n<0||n>12)||u.range[0]>u.range[1])throw Error('유닛 분류 또는 사거리가 손상되었습니다.');
  for(const k of ['hp','maxHP','mp','maxMP','atk','def','mag','res','spd','mov','x','y'])if(!Number.isFinite(u[k])||u[k]<0||!Number.isInteger(u[k]))throw Error('유닛 수치가 올바르지 않습니다.');
  if(u.classMovementModifier!=null&&(!Number.isInteger(u.classMovementModifier)||u.classMovementModifier<0||u.classMovementModifier>5)||u.movementProfile!=null&&!['infantry','rogue','cavalry','ranger'].includes(u.movementProfile))throw Error('병종 이동 정보가 손상되었습니다.');
  if(u.hp>u.maxHP||u.mp>u.maxMP||u.maxHP<1||u.x>=mission.width||u.y>=mission.height||!Number.isFinite(terrainAt(u.x,u.y,s)?.cost))throw Error('유닛 위치 또는 HP가 손상되었습니다.');
  if(alive(u)){const p=`${u.x},${u.y}`;if(occupied.has(p))throw Error('유닛이 중복 배치되었습니다.');occupied.add(p);}
  // v0.8.0 statuses and one-turn marks.
  if(!validStatus(u.status)||u.provokedBy!=null&&(typeof u.provokedBy!=='object'||typeof u.provokedBy.id!=='string'||!Number.isInteger(u.provokedBy.turn))||['rally','drum','immuneUntil','provokeGuard'].some(k=>u[k]!=null&&!Number.isInteger(u[k]))||['atkDown','defDown'].some(k=>u[k]!=null&&(!Number.isInteger(u[k].n)||!Number.isInteger(u[k].until))))throw Error('상태이상 기록이 손상되었습니다.');
  if(u.recoveryPhase!=null&&(typeof u.recoveryPhase!=='string'||!/^([1-9][0-9]*):(player|enemy)$/.test(u.recoveryPhase)||Number(u.recoveryPhase.split(':')[0])>s.turn))throw Error('회복 Phase 기록이 손상되었습니다.');
  if(u.team==='ally'&&(!party.includes(u.id)||!Number.isInteger(u.level)||u.level<1||!Number.isInteger(u.xp)||u.xp<0||u.xp>=100||!Array.isArray(u.clues)||!Array.isArray(u.growthHistory)||!Array.isArray(u.highlights)||!Array.isArray(u.healTargets)))throw Error('성장 기록이 손상되었습니다.');
  if(u.team==='ally'&&(!Number.isInteger(u.earnedXP)||u.earnedXP<0||u.clues.some(c=>typeof c!=='string')||u.highlights.some(h=>typeof h!=='string')||u.growthHistory.some(g=>!g||!Number.isInteger(g.level)||!g.changes)||typeof u.moved!=='boolean'||typeof u.acted!=='boolean'))throw Error('장수 행동 또는 성장 기록이 손상되었습니다.');
 }
 for(const id of [...party,...[...mission.enemies,...mission.civilians,...(mission.objects||[]),...allies].map(u=>u.id)])if(!ids.has(id))throw Error('필수 유닛이 없습니다.');
 const cells=v=>v==null||Array.isArray(v)&&v.length<=60&&v.every(c=>c&&Number.isInteger(c.x)&&Number.isInteger(c.y)&&(c.until==null||Number.isInteger(c.until)));
 if(s.throws!=null&&(!Number.isInteger(s.throws)||s.throws<0||s.throws>THROW_LIMIT)||!cells(s.smoke)||!cells(s.traps))throw Error('투척 도구 기록이 손상되었습니다.');
 if(!Array.isArray(s.enemyQueue)||!Number.isInteger(s.enemyIndex)||s.enemyIndex<0||s.enemyIndex>s.enemyQueue.length||!s.undo||!Number.isInteger(s.potions)||s.potions<0||s.potions>2)throw Error('전투 상태가 손상되었습니다.');
 if(s.enemyQueue.some(id=>!s.units.some(u=>u.id===id&&(u.team==='enemy'||u.team==='allied'))))throw Error('AI 순서가 손상되었습니다.');
 if(s.campaign.heroes!==null){const n=s.campaign.heroes.length;if(!Array.isArray(s.campaign.heroes)||n<5||n>ALL_HEROES.length||new Set(s.campaign.heroes.map(u=>u.id)).size!==n||HEROES.some(h=>!s.campaign.heroes.some(u=>u.id===h.id)))throw Error('군단 성장 저장이 손상되었습니다.');for(const u of s.campaign.heroes){if(!party.includes(u.id)||!Array.isArray(u.clues)||!Array.isArray(u.growthHistory)||['level','xp','maxHP','maxMP','atk','def','mag','res','spd'].some(k=>!Number.isInteger(u[k])||u[k]<0))throw Error('군단 수치가 손상되었습니다.');}}
 if(s.log.some(l=>typeof l!=='string')||s.missionStart.length!==party.length||s.missionStart.some(m=>!m||!party.includes(m.id)||!m.stats||!Number.isInteger(m.level)))throw Error('미션 기록이 손상되었습니다.');
 if(s.outcome!==null&&!['victory','defeat'].includes(s.outcome)||s.screen==='result'&&!s.outcome)throw Error('미션 결과가 손상되었습니다.');
 if(s.stageStart!=null){const initial=s.stageStart;if(initial.stageStart!=null||initial.screen!=='battle'||initial.phase!=='player'||initial.turn!==1||initial.initialSeed!==s.initialSeed||initial.rng!==s.initialSeed||initial.potions!==2||initial.reinforced||initial.missionId!==s.missionId||!(initial.units?.length>=(party.length+allies.length+mission.enemies.length+mission.civilians.length+(mission.objects||[]).length)&&initial.units.length<=(party.length+allies.length+mission.enemies.length+mission.civilians.length+(mission.objects||[]).length+(mission.waves||[]).filter(w=>w.trigger==='start').reduce((n,w)=>n+w.units.length,0)))||initial.units?.some(u=>u.team==='ally'&&(u.moved||u.acted)||u.team==='civilian'&&u.rescued))throw Error('스테이지 시작 기록이 손상되었습니다.');validate(initial);}
 const n=s.narrative,c=s.campaign;
 if(!n||!Array.isArray(n.queue)||!Array.isArray(n.events)||!Array.isArray(n.seen)||!Array.isArray(n.history)||n.queue.length>50||n.history.length>250||[...n.queue,...n.events,...n.seen].some(k=>!STORY[k]))throw Error('대화 기록이 손상되었습니다.');
 if(n.active&&(!STORY[n.active.key]||!Number.isInteger(n.active.index)||n.active.index<0||n.active.index>=STORY[n.active.key].length))throw Error('대화 위치가 손상되었습니다.');
 if(!Array.isArray(c.completed)||c.completed.some(id=>!MISSIONS[id])||!c.flags||!c.bonds||!c.tacticalMemory||[c.flags,c.bonds,c.tacticalMemory].some(v=>typeof v!=='object'||Array.isArray(v))||Object.values(c.tacticalMemory).some(v=>!Number.isInteger(v)||v<0))throw Error('캠페인 상태가 손상되었습니다.');
 if(c.choices!=null&&(typeof c.choices!=='object'||Array.isArray(c.choices)||Object.values(c.choices).some(v=>typeof v!=='string'||v.length>40)))throw Error('선택 기록이 손상되었습니다.');
 if(rulesOf(s)&&!rulesOf(s).validState(s.missionState))throw Error('임무 진행 기록이 손상되었습니다.');
 if(s.burning!=null&&(typeof s.burning!=='object'||Array.isArray(s.burning)||Object.entries(s.burning).some(([k,v])=>!/^\d{1,2},\d{1,2}$/.test(k)||!Number.isInteger(v)||v<1||v>2)))throw Error('화염 기록이 손상되었습니다.');
 if(s.units.some(u=>u.team==='ally'&&(![1,2,3].includes(u.appearanceTier)||['classTier','storyTier'].some(k=>u[k]!=null&&![1,2,3].includes(u[k])))))throw Error('외형 Tier가 손상되었습니다.');
 // v0.8.1: hidden objectives won (mission ids), this battle's flag record, the supply carrier's crate.
 if(c.feats!=null&&(!Array.isArray(c.feats)||c.feats.length>20||new Set(c.feats).size!==c.feats.length||c.feats.some(id=>!Number.isInteger(id)||id<1||id>20)))throw Error('숨은 전과 기록이 손상되었습니다.');
 if(s.battleFlags!=null&&(typeof s.battleFlags!=='object'||Array.isArray(s.battleFlags)||Object.keys(s.battleFlags).length>60||Object.values(s.battleFlags).some(v=>!['boolean','number','string'].includes(typeof v)||typeof v==='string'&&v.length>40)))throw Error('전투 기록이 손상되었습니다.');
 if(s.units.some(u=>u.carrier!=null&&(!['enemy','allied'].includes(u.team)||typeof u.carrier!=='string'||!TOOLS[u.carrier])||u.pouchUsed!=null&&typeof u.pouchUsed!=='boolean'))throw Error('보급 기록이 손상되었습니다.');
 // v0.9.0 (D-079): the duel of this battle, Aren's command, the weather's cleared tiles and a turned watchman.
 if(s.duel!=null&&!validDuel(s,s.duel)||s.command!=null&&!COMMANDS[s.command]||s.units.some(u=>u.turned!=null&&(u.turned!==true||u.team!=='enemy')))throw Error('ACT III 전투 기록이 손상되었습니다.');
 // v0.9.1: the ④ skills used this battle, Elina's blockade, the oath wall, Thea's remaining run, raised heroes, woken statues.
 if(s.ultimates!=null&&(!Array.isArray(s.ultimates)||new Set(s.ultimates).size!==s.ultimates.length||s.ultimates.some(id=>!['eric','elina','sain','lia','kai'].includes(id)||!party.includes(id)))||s.blockade!=null&&(typeof s.blockade!=='object'||!party.includes(s.blockade.by)||!Number.isInteger(s.blockade.turn)||!Array.isArray(s.blockade.cells)||s.blockade.cells.length>5||s.blockade.cells.some(c=>!Array.isArray(c)||c.length!==2||!c.every(Number.isInteger)))||s.units.some(u=>u.oathWall!=null&&(u.id!=='eric'||!Number.isInteger(u.oathWall))||u.moveLeft!=null&&(!Number.isInteger(u.moveLeft)||u.moveLeft<0||u.moveLeft>12)||['raised','oathUsed'].some(k=>u[k]!=null&&typeof u[k]!=='boolean')||u.woke!=null&&!['ally','enemy'].includes(u.woke)))throw Error('각성 전투 기록이 손상되었습니다.');
 // v0.9.2: Lia's Little Ward, Kai's Shadow Dance (an enemy held this turn), the grey cloaks' shadow, M19 captives and the M20 archive.
 if(s.smallWard!=null&&(typeof s.smallWard!=='object'||s.smallWard.by!=='lia'||!party.includes('lia')||!['x','y','until'].every(k=>Number.isInteger(s.smallWard[k])&&s.smallWard[k]>=0)||s.smallWard.x>=mission.width||s.smallWard.y>=mission.height||s.smallWard.until>s.turn+1)||s.units.some(u=>u.dazed!=null&&(u.team!=='enemy'||!Number.isInteger(u.dazed)||u.dazed>s.turn)||u.shade!=null&&u.shade!==true||['forgotten','freed','noRescue','burned'].some(k=>u[k]!=null&&typeof u[k]!=='boolean')))throw Error('그림자 전투 기록이 손상되었습니다.');
 validateEconomy(s.economy);validateEconomy(s.campaign.economy);if(s.frontier)validateFrontier(s.frontier);if(s.campaign.frontier)validateFrontier(s.campaign.frontier);
 return s;
}
// Exported for the migration tests: the economy as a schema-10 save's economy reads in schema 11.
export function arms081View(e){const c=structuredClone(e);arms081(c);return c;}
function arms081(e){for(const g of e.gear||[]){if('level' in g){g.star=g.level===1?2:1;g.exp=g.level===1?30:0;delete g.level;}}for(const slots of Object.values(e.equipped||{}))if(slots&&!Object.hasOwn(slots,'treasure'))slots.treasure=null;for(const r of e.rewardPending||[])delete r.level;}
export function migrate(s){
 if(s?.schema===0){s.schema=1;s.feedback=s.feedback||[];}
 if(s?.schema===1){s.schema=2;s.version='0.2.0';s.missionId=1;s.practice=false;s.narrative=narrativeState();const c=s.campaign;c.completed=c.clears>0?[1]:[];c.flags=c.clears>0?{mission_01_completed:true}:{};c.bonds={};c.tacticalMemory={};for(const u of [...s.units,...(c.heroes||[])])if(u.team==='ally'||HEROES.some(h=>h.id===u.id)){u.appearanceTier=u.id==='eric'&&u.level>=5?2:1;const h=HEROES.find(h=>h.id===u.id);u.name=h.name;u.ko=h.ko;}if(s.stageStart)s.stageStart=migrate(s.stageStart);}
 if(s?.schema===2){s.schema=3;s.version='0.3.0';ensureEconomy(s);s.frontier=frontierState(s.missionId);s.campaign.frontier=structuredClone(s.frontier);if(s.stageStart)s.stageStart=migrate(s.stageStart);}
 if(s?.schema===3){s.schema=4;s.version='0.3.1';for(const u of [...s.units,...(s.campaign.heroes||[])]){const h=HEROES.find(h=>h.id===u.id);if(h)u.mov=h.mov;}if(s.stageStart)s.stageStart=migrate(s.stageStart);}
 if(s?.schema===4){s.schema=5;s.version='0.3.2';legacyRewardCatchup(s.campaign.economy,s.campaign);legacyRewardCatchup(s.economy,s.campaign);if(s.stageStart)s.stageStart=migrate(s.stageStart);}
 if(s?.schema===5){s.schema=6;s.version='0.3.3';s.frontier=migrateFrontier(s.frontier,s.missionId);s.campaign.frontier=migrateFrontier(s.campaign.frontier,s.missionId);if(s.stageStart)s.stageStart=migrate(s.stageStart);}
 if(s?.schema===6){s.schema=7;s.version='0.4.0';s.campaign.choices??={};if(s.stageStart)s.stageStart=migrate(s.stageStart);}
 if(s?.schema===7){s.schema=8;s.version='0.5.0';s.campaign.promotions??={};if(s.stageStart)s.stageStart=migrate(s.stageStart);}
 // v0.6 (Phase C): an empty ACT II roster. Faction trust is seeded from the ACT I choices when ACT II begins
 // (factions.js ensureTrust), so a save from the middle of ACT I keeps its M04 ledger choice open.
 if(s?.schema===8){s.schema=9;s.version='0.6.0';s.campaign.roster??=[];if(s.stageStart)s.stageStart=migrate(s.stageStart);}
 // v0.8.0 (D-073): new tools join the bag lazily (items hold only the kinds ever owned), statuses and throwables live
 // on the battle state; nothing in a schema-9 save has to change.
 if(s?.schema===9){s.schema=10;s.version='0.8.0';if(s.stageStart)s.stageStart=migrate(s.stageStart);}
 // v0.8.1 (D-073 Q5): gear grows by stars — the old +1 upgrade becomes ★2 (its EXP filled), plain gear ★1; every hero gains a
 // treasure slot; the hidden-objective record starts empty (cleared missions can still win theirs in practice).
 if(s?.schema===10){s.schema=11;s.version='0.8.1';for(const e of [s.economy,s.campaign?.economy])if(e)arms081(e);s.campaign.feats??=[];if(s.screen==='battle'||s.screen==='result')s.battleFlags??={};if(s.skirmish?.campaign?.economy)arms081(s.skirmish.campaign.economy);if(s.stageStart)s.stageStart=migrate(s.stageStart);}
 // v0.9.0 (D-079): ACT III adds a duel, Aren's command and new missions on the battle state; a schema-11 save keeps everything.
 if(s?.schema===11){s.schema=12;s.version='0.9.0';if(s.stageStart)s.stageStart=migrate(s.stageStart);}
 // v0.9.1 (D-084): awakening (tier 3), the recruits' tier 2, the ④ skills and M17–M18 add battle fields; a schema-12 save keeps everything.
 if(s?.schema===12){s.schema=13;s.version='0.9.1';if(s.stageStart)s.stageStart=migrate(s.stageStart);}
 // v0.9.2 (D-089): Lia's and Kai's awakening, M19–M20 and 「한 사람도 두고 가지 않는다」 add battle fields; a schema-13 save keeps everything.
 if(s?.schema===13){s.schema=14;s.version='0.9.2';if(s.stageStart)s.stageStart=migrate(s.stageStart);}
 if(s?.schema>SCHEMA)throw Error('더 최신 버전의 저장입니다.');
 // v0.6.1: a save of the current schema made by an earlier build of it (e.g. v0.6.0) is now this version.
 if(s?.schema===SCHEMA&&s.version!==VERSION){s.version=VERSION;if(s.stageStart?.version)s.stageStart.version=VERSION;}
 // v0.6 (D-060): character names are written in Hangul; saves made before keep English names on board until renamed here.
 if(s?.schema===SCHEMA)koreanNames(s);
 // v0.6 (D-062): rewritten scenes can differ in length; a save paused inside a scene resumes on its last line at most.
 if(s?.schema===SCHEMA)for(const n of [s.narrative,s.stageStart?.narrative]){const a=n?.active,len=a&&STORY[a.key]?.length;if(len&&Number.isInteger(a.index)&&a.index>=len)a.index=len-1;}
 // v0.5 hubs (D-052): every load re-anchors the frontier to the hub of its story moment (spatial only).
 if(s?.schema===SCHEMA){if(s.frontier)alignFrontier(s.frontier,s.missionId,s.screen);if(s.campaign?.frontier)alignFrontier(s.campaign.frontier,s.missionId,s.screen);if(s.skirmish?.frontier)alignFrontier(s.skirmish.frontier,s.skirmish.returnMission,'exploration');if(s.stageStart?.frontier)alignFrontier(s.stageStart.frontier,s.stageStart.missionId,s.stageStart.screen);if(s.stageStart?.campaign?.frontier)alignFrontier(s.stageStart.campaign.frontier,s.stageStart.missionId,s.stageStart.screen);}
 return validate(s);
}
const KO_NAMES={'Erik':'에릭','Elina':'엘리나','Lia':'리아','Sain':'세인','Kai':'카이','Thea':'테아','Dario':'다리오','Rook':'룩','Varr':'바르','Cinder':'신더','Ash Bow':'애시 보우',
 'Garr — Bandit Captain':'가르 — 산적 두목','North Raider':'북쪽 습격대원','North Bow':'북쪽 궁수','Mira':'미라','부상한 Mira':'부상한 미라','Tomas':'토마스','Baldrick Roen · 검은 사자':'발드릭 로엔 · 검은 사자'};
function koreanNames(s){for(const list of [s.units,s.campaign?.heroes,s.stageStart?.units,s.stageStart?.campaign?.heroes])for(const u of list||[])if(KO_NAMES[u.name])u.name=KO_NAMES[u.name];}
export function serialize(s){validate(s);const data=JSON.stringify({...s,feedback:[]});return JSON.stringify({format:'AshenCrown',schema:SCHEMA,checksum:checksum(data),data});}
export function deserialize(text){if(typeof text!=='string'||text.length>5000000)throw Error('저장 크기가 올바르지 않습니다.');const envelope=JSON.parse(text);if(envelope.format!=='AshenCrown'||typeof envelope.data!=='string'||checksum(envelope.data)!==envelope.checksum)throw Error('저장 검증에 실패했습니다.');return migrate(JSON.parse(envelope.data));}
export function saveGame(s,storage){let old,previousBackup,writing=false;try{const data=serialize(s);old=storage.getItem(SAVE_KEY);previousBackup=storage.getItem(BACKUP_KEY);if(old){try{deserialize(old);storage.setItem(BACKUP_KEY,old);}catch{}}
 writing=true;storage.setItem(SAVE_KEY,data);if(storage.getItem(SAVE_KEY)!==data)throw Error('저장 확인 실패');return {ok:true};}catch(e){if(writing){try{if(old===null)storage.removeItem(SAVE_KEY);else storage.setItem(SAVE_KEY,old);if(previousBackup===null)storage.removeItem(BACKUP_KEY);else storage.setItem(BACKUP_KEY,previousBackup);}catch{}}return {ok:false,error:e.message};}}
export function loadGame(storage){try{const data=storage.getItem(SAVE_KEY);if(!data)return {state:null};try{return {state:deserialize(data)};}catch(primary){const backup=storage.getItem(BACKUP_KEY);if(backup)return {state:deserialize(backup),warning:'최근 저장이 손상되어 이전 정상 저장을 복구했습니다.'};return {state:null,warning:`저장을 불러올 수 없습니다: ${primary.message}`};}}catch(e){return {state:null,warning:`브라우저 저장을 사용할 수 없습니다: ${e.message}`};}}
export function resetSave(storage){try{storage.removeItem(SAVE_KEY);storage.removeItem(BACKUP_KEY);return {ok:true};}catch(e){return {ok:false,error:e.message};}}
