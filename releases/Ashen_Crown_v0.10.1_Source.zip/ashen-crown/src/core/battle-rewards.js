import {GEAR,TOOLS} from '../data/frontier-data.js';
// Supplement existing first-clear Gold, never replace or repeat it.
export function supplementalRewards(missionId,{rescued=0,captured=false,seal=false,orders=false,broken=false,wagons=0,refugees=0,beacon=false,convoy=0,captured7=false,villagers=0,captain8=false,delegates=0,captured9=false,villagers10=0,mediated=false,pilgrims=0,braziers=0,silent12=false,abbot12=false,halted13=false,refugees13=0,escort14=0,boxes15=0,calm15=false,echoes16=0,sworn17=0,trees18=0,remembered19=0,cabinets20=0,residents20=0,keepers18=0,anchors21=0,heralds22=0,leaders23=0,inside24=0,leadersHalf25=false,baldrick26=null}={}){
 const reward=(suffix,kind,type,amount=1,optional=false)=>({id:`v032:m${missionId}:${suffix}`,missionId,kind,type,amount,optional});
 if(missionId===1)return [reward('supply','item','medium'),...(rescued===2?[reward('rescue','item','ward',1,true)]:[])];
 if(missionId===2)return [reward('supply','item','ether'),...(captured?[reward('capture','gold',null,30,true)]:[])];
 if(missionId===3)return [reward('supply-hp','item','medium'),reward('supply-mp','item','ether'),...(rescued===2?[reward('full-rescue','gear','focusCharm',1,true)]:[])];
 const v4=(suffix,kind,type,amount=1,optional=false)=>({...reward(suffix,kind,type,amount,optional),id:`v040:m${missionId}:${suffix}`});
 if(missionId===4)return [v4('supply','item','medium'),...(seal?[v4('seal-notes','gear','focusCharm',1,true)]:[]),...(orders?[v4('orders','gold',null,40,true)]:[]),...(seal&&orders?[v4('all-evidence','item','ether',1,true)]:[])];
 if(missionId===5)return [v4('supply-mp','item','ether'),v4('supply-hp','item','medium'),...(broken?[v4('formation-broken','gear','heavyShield',1,true)]:[]),...(wagons===2?[v4('both-wagons','gold',null,50,true)]:[])];
 if(missionId===6)return [v4('supply-hp','item','medium'),v4('supply-mp','item','ether'),...(refugees===4?[v4('all-refugees','gear','trailBoots',1,true)]:[]),...(beacon?[v4('beacon','gold',null,60,true)]:[])];
 // v0.6 ACT II (PROPOSED): first-clear supplies plus optional rewards for a full convoy, a captured captain, rescued villagers.
 const v6=(suffix,kind,type,amount=1,optional=false)=>({...reward(suffix,kind,type,amount,optional),id:`v060:m${missionId}:${suffix}`});
 if(missionId===7)return [v6('supply-hp','item','medium'),v6('supply-mp','item','ether'),...(convoy===3?[v6('full-convoy','gold',null,70,true)]:[]),...(captured7?[v6('captain','item','ward',1,true)]:[])];
 if(missionId===8)return [v6('supply-hp','item','medium'),v6('supply-mp','item','ether'),...(villagers===3?[v6('all-villagers','gear','focusCharm',1,true)]:[]),...(captain8?[v6('captain','gold',null,80,true)]:[])];
 // v0.6.1 (PROPOSED): M09 every delegate safe → a longbow, the assassin leader taken alive → a ward; M10 all villagers → 80 gold, a truce → a travel cloak.
 const v61=(suffix,kind,type,amount=1,optional=false)=>({...reward(suffix,kind,type,amount,optional),id:`v061:m${missionId}:${suffix}`});
 if(missionId===9)return [v61('supply-hp','item','medium'),v61('supply-mp','item','ether'),...(delegates===3?[v61('all-delegates','gear','longbow',1,true)]:[]),...(captured9?[v61('assassin','item','ward',1,true)]:[])];
 if(missionId===10)return [v61('supply-hp','item','medium'),v61('supply-mp','item','ether'),...(villagers10===3?[v61('all-villagers','gold',null,80,true)]:[]),...(mediated?[v61('truce','gear','travelCloak',1,true)]:[])];
 // v0.7.0 (PROPOSED, D-068): M11 every pilgrim through → a mercy staff, all three braziers lit → 70 gold; M12 the ledger secured before the bell → balanced daggers, the abbot taken alive → a ward.
 const v7=(suffix,kind,type,amount=1,optional=false)=>({...reward(suffix,kind,type,amount,optional),id:`v070:m${missionId}:${suffix}`});
 if(missionId===11)return [v7('supply-hp','item','medium'),v7('supply-mp','item','ether'),...(pilgrims===4?[v7('all-pilgrims','gear','mercyStaff',1,true)]:[]),...(braziers===3?[v7('braziers','gold',null,70,true)]:[])];
 if(missionId===12)return [v7('supply-hp','item','medium'),v7('supply-mp','item','ether'),...(silent12?[v7('silent','gear','daggers',1,true)]:[]),...(abbot12?[v7('abbot','item','ward',1,true)]:[])];
 // v0.7.1 (PROPOSED, D-071): M13 every refugee safe → a heavy shield, Baldrick halted → 80 gold; M14 every loyal leader and guard out alive → a focus charm.
 const v71=(suffix,kind,type,amount=1,optional=false)=>({...reward(suffix,kind,type,amount,optional),id:`v071:m${missionId}:${suffix}`});
 if(missionId===13)return [v71('supply-hp','item','medium'),v71('supply-mp','item','ether'),...(refugees13===4?[v71('all-refugees','gear','heavyShield',1,true)]:[]),...(halted13?[v71('halted','gold',null,80,true)]:[])];
 if(missionId===14)return [v71('supply-hp','item','medium'),v71('supply-mp','item','ether'),...(escort14>=6?[v71('whole-escort','gear','focusCharm',1,true)]:[])];
 // v0.9.0 (PROPOSED, D-079): M15 every box recovered → 90 gold, the watch never warned → a ward; M16 every ward stone searched → a clarity charm.
 const v9=(suffix,kind,type,amount=1,optional=false)=>({...reward(suffix,kind,type,amount,optional),id:`v090:m${missionId}:${suffix}`});
 if(missionId===15)return [v9('supply-hp','item','medium'),v9('supply-mp','item','ether'),...(boxes15===3?[v9('all-boxes','gold',null,90,true)]:[]),...(calm15?[v9('quiet-watch','item','ward',1,true)]:[])];
 if(missionId===16)return [v9('supply-hp','item','medium'),v9('supply-mp','item','ether'),...(echoes16===3?[v9('all-echoes','item','clarity',1,true)]:[])];
 // v0.9.1 (PROPOSED, D-084): M17 every statue sworn → 100 gold; M18 every tree standing → a ward, every forest-keeper inside → an elixir.
 const v91=(suffix,kind,type,amount=1,optional=false)=>({...reward(suffix,kind,type,amount,optional),id:`v091:m${missionId}:${suffix}`});
 if(missionId===17)return [v91('supply-hp','item','medium'),v91('supply-mp','item','ether'),...(sworn17===4?[v91('all-statues','gold',null,100,true)]:[])];
 if(missionId===18)return [v91('supply-hp','item','medium'),v91('supply-mp','item','ether'),...(trees18===3?[v91('all-trees','item','ward',1,true)]:[]),...(keepers18===6?[v91('all-keepers','item','elixir',1,true)]:[])];
 // v0.9.2 (PROPOSED, D-089): M19 every captive keeps their name → 100 gold; M20 every cabinet → a clarity, every resident → an elixir.
 const v92=(suffix,kind,type,amount=1,optional=false)=>({...reward(suffix,kind,type,amount,optional),id:`v092:m${missionId}:${suffix}`});
 if(missionId===19)return [v92('supply-hp','item','medium'),v92('supply-mp','item','ether'),...(remembered19===4?[v92('all-names','gold',null,100,true)]:[])];
 if(missionId===20)return [v92('supply-hp','item','medium'),v92('supply-mp','item','ether'),...(cabinets20===3?[v92('all-cabinets','item','clarity',1,true)]:[]),...(residents20===6?[v92('all-residents','item','elixir',1,true)]:[])];
 // v0.9.3 (PROPOSED, D-093): M21 every anchor stone broken → an elixir; M22 every herald standing → 120 gold.
 const v93=(suffix,kind,type,amount=1,optional=false)=>({...reward(suffix,kind,type,amount,optional),id:`v093:m${missionId}:${suffix}`});
 if(missionId===21)return [v93('supply-hp','item','medium'),v93('supply-mp','item','ether'),...(anchors21===4?[v93('all-anchors','item','elixir',1,true)]:[])];
 if(missionId===22)return [v93('supply-hp','item','medium'),v93('supply-mp','item','ether'),...(heralds22===3?[v93('all-heralds','gold',null,120,true)]:[])];
 // v0.10.0 (PROPOSED, D-100): M23 every leader standing → an elixir; M24 all eight refugees inside → 140 gold.
 const v100=(suffix,kind,type,amount=1,optional=false)=>({...reward(suffix,kind,type,amount,optional),id:`v0100:m${missionId}:${suffix}`});
 if(missionId===23)return [v100('supply-hp','item','medium'),v100('supply-mp','item','ether'),...(leaders23===3?[v100('all-leaders','item','elixir',1,true)]:[])];
 if(missionId===24)return [v100('supply-hp','item','medium'),v100('supply-mp','item','ether'),...(inside24===8?[v100('all-inside','gold',null,140,true)]:[])];
 // v0.10.1 (PROPOSED, D-102): M25 both leaders above half → 150 gold; M26 Baldrick yields (joins or rides with us) → an elixir.
 if(missionId===25)return [v100('supply-hp','item','medium'),v100('supply-mp','item','ether'),...(leadersHalf25?[v100('leaders-half','gold',null,150,true)]:[])];
 if(missionId===26)return [v100('supply-hp','item','medium'),v100('supply-mp','item','ether'),...(baldrick26==='join'||baldrick26==='cooperate'?[v100('lion-yields','item','elixir',1,true)]:[])];
 return [];
}
export const knownRewards=()=>[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26].flatMap(id=>supplementalRewards(id,{leaders23:3,inside24:8,leadersHalf25:true,baldrick26:'join',anchors21:4,heralds22:3,remembered19:4,cabinets20:3,residents20:6,sworn17:4,trees18:3,keepers18:6,rescued:2,captured:true,seal:true,orders:true,broken:true,wagons:2,refugees:4,beacon:true,convoy:3,captured7:true,villagers:3,captain8:true,delegates:3,captured9:true,villagers10:3,mediated:true,pilgrims:4,braziers:3,silent12:true,abbot12:true,halted13:true,refugees13:4,escort14:6,boxes15:3,calm15:true,echoes16:3}));
export function initRewardLedger(e){e.rewardClaims??=[];e.rewardHistory??=[];e.rewardPending??=[];return e;}
export function deliverRewards(e){let count=0;for(let i=0;i<e.rewardPending.length;){const r=e.rewardPending[i];if(r.kind==='item'&&Object.values(e.items).reduce((a,b)=>a+b,0)<8){e.items[r.type]=(e.items[r.type]||0)+1;}else if(r.kind==='gear'&&e.gear.filter(g=>!GEAR[g.type]?.treasure).length<30){e.gear.push({id:`g${e.next++}`,type:r.type,star:1,exp:0});}else{i++;continue;}e.rewardPending.splice(i,1);count++;}return count;}
export function grantSupplemental(e,missionId,context={},legacy=false){initRewardLedger(e);const grants=[];for(const r of supplementalRewards(missionId,context)){if(e.rewardClaims.includes(r.id))continue;e.rewardClaims.push(r.id);e.rewardHistory.push({...r,legacy});if(r.kind==='gold')e.gold+=r.amount;else for(let n=0;n<r.amount;n++)e.rewardPending.push({...r});grants.push(r);}deliverRewards(e);return grants;}
export function legacyRewardCatchup(e,campaign){initRewardLedger(e);for(const id of campaign.completed||[]){const result=campaign.results.find(r=>r.missionId===id&&r.outcome==='victory'&&!r.practice);const rescued=result?.rescued??(id===1?campaign.flags.mission_01_civilians_rescued:id===3?campaign.flags.mission_03_refugees_saved:0)??0;grantSupplemental(e,id,{rescued,captured:!!campaign.flags.mission_02_prisoner_captured,seal:!!campaign.flags.mission_04_seal_notes,orders:!!campaign.flags.mission_04_transfer_orders,broken:campaign.flags.mission_05_baldrick_withdrew==='broken',wagons:campaign.flags.mission_05_wagons_saved||0,refugees:campaign.flags.mission_06_refugees_through||0,beacon:!!campaign.flags.mission_06_beacon_destroyed},true);}}
export function validateRewardLedger(e){const known=new Map(knownRewards().map(r=>[r.id,r]));const valid=r=>{const k=known.get(r?.id);return k&&['missionId','kind','type','amount','optional'].every(p=>r[p]===k[p]);};if(!Array.isArray(e.rewardClaims)||new Set(e.rewardClaims).size!==e.rewardClaims.length||e.rewardClaims.some(id=>!known.has(id))||!Array.isArray(e.rewardHistory)||e.rewardHistory.length!==e.rewardClaims.length||new Set(e.rewardHistory.map(r=>r.id)).size!==e.rewardHistory.length||e.rewardHistory.some(r=>!valid(r)||!e.rewardClaims.includes(r.id)||typeof r.legacy!=='boolean')||!Array.isArray(e.rewardPending)||new Set(e.rewardPending.map(r=>r.id)).size!==e.rewardPending.length||e.rewardPending.some(r=>!valid(r)||r.kind==='gold'||!e.rewardClaims.includes(r.id)))throw Error('보상 기록이 손상되었습니다.');}
export const rewardLabel=r=>r.kind==='gold'?`${r.amount} Gold`:`${r.kind==='gear'?GEAR[r.type].name:TOOLS[r.type].name} × ${r.amount}`;
