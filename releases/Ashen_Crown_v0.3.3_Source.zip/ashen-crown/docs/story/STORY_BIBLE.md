# Ashen Crown — Story Bible
## 설정 상태 규칙
CANON = 사용자 명시 확정. APPROVED_DIRECTION = 승인한 방향, 세부사항 유동적. PROPOSED = 제안, 미확정. OPEN = 미결. DEPRECATED = 폐기된 설정. 새 아이디어를 임의로 CANON으로 승격하지 않는다.
출처: 2026-10-14 사용자 v0.2.0 Master Task. 과거 대화에 의존하지 않는다. 기본 세계관·인물 배경은 이 지시의 승인 방향으로 보존하며, 명시 확정된 게임 철학·B안·4막 구조와 구분한다.

## Narrative Constitution
CANON: 전쟁 서사 SRPG, 장수 육성 중심. 핵심 주제 «평화를 얻기 위해 어디까지 희생할 수 있는가?» 아렌은 지휘관이며 기본 전투 장수와 분리. 혼합형 동료 관계 B안.
APPROVED_DIRECTION: Erdia, Aurelius, Ashen Crown, 200년 통일과 3년 전 잿빛 밤. 결계는 민간인 생존에 필수. 왕관의 전쟁·희생·기억 연관은 ACT III~IV까지 단계 공개한다.
## 역사와 정치
# World History
## 설정 상태 규칙
CANON = 사용자 명시 확정. APPROVED_DIRECTION = 승인한 방향, 세부사항 유동적. PROPOSED = 제안, 미확정. OPEN = 미결. DEPRECATED = 폐기된 설정. 새 아이디어를 임의로 CANON으로 승격하지 않는다.
출처: 2026-10-14 사용자 v0.2.0 Master Task. 과거 대화에 의존하지 않는다. 기본 세계관·인물 배경은 이 지시의 승인 방향으로 보존하며, 명시 확정된 게임 철학·B안·4막 구조와 구분한다.

APPROVED_DIRECTION: 대륙 Erdia. 약 200년 전 Aurelius가 고대 유산 Ashen Crown으로 통일했다. 왕관은 결계를 유지하며 평화를 주었다. 전쟁·희생·인간의 기억과 왕관 사이 감춰진 연관성이 있다.
3년 전 The Ashen Night(잿빛 밤): 계승 의식 실패, 국왕 실종, 세 왕족의 내전. 현재는 국경 마을의 습격에서 시작한다.
OPEN: 결계 작동 법칙, 의식 실패 책임, 실종 국왕의 생존 상태, 정확한 연표·왕조 계보. PROPOSED: 희생의 기억이 결계에 사용되지만 전쟁이 유일한 에너지원이라는 단정은 금지.

# Factions

APPROVED_DIRECTION: 세 지도자와 철학. 어느 세력도 단순 선악으로 묘사하지 않는다.

## Iron Crown Dominion
지도자: Cassian Arcane. 철학: «통일 없이는 평화도 없다.»
정치 목표: 중앙집권 통일. 장점: 군사 안정·행정·질서 회복. 위험: 권력 집중·자유 제한·군사 강압.

## Free Lords Alliance
지도자: Leonora Arcane. 철학: «왕 없는 세상에도 질서는 존재한다.»
정치 목표: 자치 연합. 장점: 지방 자치·중앙 견제·지역 이해 반영. 위험: 귀족 충돌·분열·지휘 불일치.

## Order of the Sacred Flame
지도자: Lucien Arcane. 철학: «왕국을 멸망시킨 것은 인간의 탐욕이다.»
정치 목표: 신앙과 결계 복원. 장점: 결속·구호·결계 지식. 위험: 독단·종교 권력·사상 배제.

## 주요 적대 인물
APPROVED_DIRECTION: Baldrick Roen(48), 검은 사자, 철왕관 총사령관. 에릭의 과거 상관, 아렌의 반복 라이벌, 선택에 따라 후반 영입 가능. 유능하며 다른 방식의 평화를 추구한다. 괴물 보스로 만들지 않는다.
APPROVED_DIRECTION: Marquess Bellard, 왕실 최고 재상, 왕관을 이용한 통제된 전쟁·질서 유지 구상의 핵심 적대자 후보. PROPOSED: 정치 논리의 세부·통제 구조. OPEN: 범행 범위와 각 세력의 독자적 책임. 모든 사건의 배후로 몰지 않는다.
## 주인공과 동료
Aren Valter(27) 변경 수비대 지휘관. 잿빛 밤 봉인 명령 전달의 죄책감. 병사 생존 중시, 책임 독점·판단 지연을 극복하고 동료와 책임을 공유한다(APPROVED_DIRECTION).
CANON B안: 에릭 오랜 전우 / 엘리나 수비대 정찰병 / 리아 새 협력 마도사 / 세인 피난민 치유사 / 카이 수상한 여행자. 상세 프로필은 CHARACTER_BIBLE.md.
## 전체 4막 30 Mission
# Campaign Structure

CANON: 4막 30 Mission의 제목·순서와 3개 엔딩. APPROVED_DIRECTION: 막별 중심 내용. ACT II~IV 아래 개별 사건 연결은 PROPOSED이며 세부 인과는 확정 전 검증한다.

## ACT I — 불타는 국경

국경 마을을 지키기 위해 시작한 전투가 자신의 왕국을 의심하게 되는 이야기.

| Mission | Title | 이야기·전술 목적 | 상태 |
|---|---|---|---|
| 01 | 잿빛 마을의 습격 | 국경 마을과 피난민 보호. Garr 격파 후 왕실 군용 물자를 발견한다. | APPROVED_DIRECTION |
| 02 | 숲길의 추격 | 습격자를 추적한다. 탈영병·피난민의 혼재를 확인하며 생포·섬멸·탈출의 결과가 정보를 바꾼다. | APPROVED_DIRECTION |
| 03 | 무너진 다리 | 교량 방어와 민간인 구조. 에릭의 보호, 세인의 구호, 카이의 우회가 협력으로 이어진다. 아렌이 봉인 명령을 떠올린다. | APPROVED_DIRECTION |
| 04 | 버려진 성채 | 보급망 흔적, 오래된 군령과 봉인술 기록을 조사한다. | APPROVED_DIRECTION |
| 05 | 국경의 사자 | 발드릭이 등장한다. 에릭은 과거 상관과 대치하고 아렌은 다른 평화관을 마주한다. | APPROVED_DIRECTION |
| 06 | 재의 맹세 | 왕실 명령에 반대한 아렌과 서로 다른 이유로 남은 동료들. 수비대가 독립 군단으로 변한다. | APPROVED_DIRECTION |

## ACT II — 세 개의 깃발

세 세력의 이상과 결함, 영입·동맹·배신. 아렌은 대륙 정치에 영향을 주는 군사 지도자가 된다.

| Mission | Title | 이야기·전술 목적 | 상태 |
|---|---|---|---|
| 07 | 북부의 군령 | Cassian의 통일 질서와 안전을 경험한다. | PROPOSED |
| 08 | 협곡 방어전 | 중앙군의 작전 효율과 강압의 비용을 본다. | PROPOSED |
| 09 | 자유의 도시 | Leonora의 자치와 자유를 경험한다. | PROPOSED |
| 10 | 두 영주의 전쟁 | 지방 권력의 이해 충돌과 연합 지휘의 한계를 본다. | PROPOSED |
| 11 | 성화의 행렬 | Lucien의 구호와 결계 신앙을 경험한다. | PROPOSED |
| 12 | 침묵의 수도원 | 교단 지식과 독단의 긴장을 조사한다. | PROPOSED |
| 13 | 검은 사자의 결단 | 발드릭의 명예와 국가 충성이 갈라지는 선택. | PROPOSED |
| 14 | 부서진 동맹 | 동맹·배신·영입의 결과가 군단을 재편한다. | PROPOSED |

## ACT III — 왕관의 진실

전쟁·희생·기억과 결계의 연결. 아렌의 과거·재상의 계획·국왕의 진실, 동료 핵심 각성.

| Mission | Title | 이야기·전술 목적 | 상태 |
|---|---|---|---|
| 15 | 사라진 기록 | 잿빛 밤의 기록 공백을 추적한다. | PROPOSED |
| 16 | 잊힌 전장 | 전쟁 희생과 결계의 연관성을 조사한다. | PROPOSED |
| 17 | 수호자의 맹세 | 고대 수호 체계와 동료의 각성 계기를 만난다. | PROPOSED |
| 18 | 불타지 않는 숲 | 결계가 보호하는 생태와 그 비용을 발견한다. | PROPOSED |
| 19 | 금지된 의식 | 기억·희생을 다루는 의식의 한계를 검증한다. | PROPOSED |
| 20 | 왕관의 그림자 | 왕관의 작동과 통제된 전쟁 구상을 연결한다. | PROPOSED |
| 21 | 마지막 국왕 | 실종된 국왕의 선택과 아렌의 과거를 대면한다. | PROPOSED |
| 22 | 잿빛 선택 | 진실을 공유하고 책임질 전쟁·결계 정책을 선택한다. | PROPOSED |

## ACT IV — 잿빛 왕관

최후의 전쟁, 왕관 처리와 새 통치 질서. 동료와 세력의 운명.

| Mission | Title | 이야기·전술 목적 | 상태 |
|---|---|---|---|
| 23 | 전쟁의 끝을 향해 | 동맹과 군단의 경험을 최후 작전에 모은다. | PROPOSED |
| 24 | 최후의 국경 | 전쟁 종결과 민간인 보호가 충돌한다. | PROPOSED |
| 25 | 세 왕가의 깃발 | 세 정치 질서가 마지막 타협 또는 대결에 임한다. | PROPOSED |
| 26 | 검은 사자의 마지막 전투 | 발드릭의 적대·협력·영입 선택의 결말. | PROPOSED |
| 27 | 왕도의 성문 | 최종 공세에서 장수들의 육성을 체감한다. | PROPOSED |
| 28 | 잿빛 밤의 진실 | 의식 실패·국왕 실종·봉인 명령의 인과를 공개한다. | PROPOSED |
| 29 | 왕관의 심장 | 마르케스와 대결하고 결계를 유지할 대안을 실행한다. | PROPOSED |
| 30 | 왕관 없는 새벽 | 왕권·연합·공동 서약 중 새로운 질서와 동료의 운명. | PROPOSED |

# Endings
CANON: A 하나의 왕국 / B 자유로운 대륙 / C 새로운 서약. 세 엔딩은 각각 이익과 희생을 가진다. C를 정답으로 평가하지 않는다.
- A: 왕권 복원, 왕관 힘 제한. PROPOSED 비용: 권력 집중과 감시를 견제할 제도 필요.
- B: 지역 연합 질서. PROPOSED 비용: 지역 불평등, 군사·결계 협의 지연.
- C: 분산 결계 공동 관리. PROPOSED 비용: 유지 부담 분산, 관리 실패와 상호 의존 위험.
OPEN: 세 엔딩 모두 민간인 생존을 지탱할 결계 전환의 구체적 공학·정치·희생 조건. 왕관 파괴만으로 문제가 해결되지 않는다. 판정 수치·장수 epilogue 미구현.

## 정보 공개와 인과 검증
ACT I: 군용 물자, 탈영·피난, 봉인 명령 기억만 공개. ACT II: 세 세력의 실제 비용과 정치적 모순. ACT III: 작동 원리·국왕·재상 가설 검증. ACT IV: 잿빛 밤 인과와 대안 실행.
OPEN: Garr 물자 획득 경로. 구현 대사는 상자에 군용 인장이 있다는 관찰만 확정하며 범인을 단정하지 않는다.
PROPOSED: 스승·정보 조직이 보급망과 연결되는 세부. OPEN: 스승 이름·정체·동료 성씨·나이(아렌/발드릭 외)·구체적 과거 사건. 미확정 세부를 새로 CANON화 금지.
Continuity audit: 의식→명령→피난 희생→내전의 시간 순서, 세 세력 독립 동기, 결계 전환 생존성, C 엔딩 비용, 발드릭 영입 조건을 후속 Narrative 작업에서 검증한다.

v0.3 continuity: M01 이전 Ashen Village 짧은 탐색/동료 소개 → 습격 확인 → 기존 전투. M01 이후 마을 반응, M02 전 Border Camp, M03 전 구조 작전, M03 후 야영지 회고. 사건·관계·왕실 보급의 관찰 범위를 보존. M04–06은 v0.4. 신규 마을 주민의 말과 세부 성격은 PROPOSED, 배후·왕관 원리를 확정하지 않는다.

## v0.3.3 user-approved viewpoint — CANON D-031/032
Erik is the directly controlled exploration and battle protagonist. Aren remains commander and keeps his past and crown arc; this supersedes any older avatar implication without transferring history. Advisor dialogue opens war council. Original4 acts/30 missions/factions/endings remain intact; no new personal advisor lore canonized.
