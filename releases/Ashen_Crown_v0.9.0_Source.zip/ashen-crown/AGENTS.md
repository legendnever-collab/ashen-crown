# Ashen Crown — Required developer entry point

개발 전에 순서대로 읽는다:

1. [docs/handoff/PROJECT_CONTEXT.md](docs/handoff/PROJECT_CONTEXT.md)
2. [docs/vision/PRODUCT_VISION.md](docs/vision/PRODUCT_VISION.md)
3. [docs/vision/GAME_DESIGN_PRINCIPLES.md](docs/vision/GAME_DESIGN_PRINCIPLES.md)
4. [docs/story/STORY_BIBLE.md](docs/story/STORY_BIBLE.md)
5. [docs/story/CHARACTER_BIBLE.md](docs/story/CHARACTER_BIBLE.md)
6. [docs/story/CAMPAIGN_STRUCTURE.md](docs/story/CAMPAIGN_STRUCTURE.md)
7. [docs/vision/DEVELOPMENT_ROADMAP.md](docs/vision/DEVELOPMENT_ROADMAP.md)
8. [docs/handoff/CURRENT_STATUS.md](docs/handoff/CURRENT_STATUS.md)
9. [docs/handoff/NEXT_TASKS.md](docs/handoff/NEXT_TASKS.md)
10. [docs/decisions/DECISION_LOG.md](docs/decisions/DECISION_LOG.md)

코드·문서 차이를 보고한다. 스토리 CANON을 소스의 우연한 구현으로 덮어쓰지 않는다. 구현 여부는 코드·테스트가 기준. 기존 Mission01/combat/save/성장 보존, 신규 아이디어 CANON 승격 금지, Aren 필수 출전 금지, 저작물 복제 금지. 사용자 리뷰 전 현재 개발 버전 자동 병합 금지. v0.2는 사용자 승인으로 PR #5 병합 완료(fdcdcc4).
작업 단계별 커밋. npm test, balance, browser regression, campaign E2E, migration, offline, documentation audit. 실제 검증만 완료 표시. 모든 PR의 documentation checklist: README, CHANGELOG, CURRENT_STATUS, NEXT_TASKS, ROADMAP, Story Bible review, Decision Log review, tests/evidence, artifacts.


## Current v0.9 entry (ACT III part 1 release candidate)
ACT III design docs/v0.9.0/ACT3_DESIGN.md (D-078) approved on 2026-11-03 18:21 KST with the recommended answers; art stays temporary until packs D, E and the ACT III art are made together (D-079). v0.9.0 「왕도」 on feature/v0.9-act3-crown (D-080): M15–M16 in src/core/mission-rules-v090.js (data in missions.js, story-v090.js, talk-v090.js), fog in rules.js, the duel in src/core/duel.js, Aren's commands in src/core/command.js, recruits' return (rejoinRoster), capital and field camp hubs, schema 12 (imports 0–11). Never merge before the user plays and approves the release candidate. Next: v0.9.1 (M17–M18, awakening Tier 3) on the user's instruction.

## Current v0.8.1 entry (merged)
v0.8.1 「무기」 (D-076, within D-073 §6) on feature/v0.8.1-arms: regional and elite gear with town shelves and Velmar's rare-goods shelf, revisiting towns from the world map (frontier.revisit), gear stars and 단련, a treasure slot and twelve treasures, one hidden objective per mission (s.battleFlags, campaign.feats; practice wins it once), supply carriers, cut-ins. Code: src/core/arms.js, src/data/arms-v081.js. Schema 11 imports 0–10 (+1 → ★2). Art work pack E is imported with scripts/import-item-art.py when the user returns it (src/assets/items); until then temporary icons. Approved by the user on 2026-11-03 (D-077) and merged via PR #17 with the temporary icons. Never merge a release candidate before the user plays and approves it. Next: ACT III and awakening only on the user's instruction.

## Current v0.8 entry (v0.8.0 merged)
v0.8.0 「전술」 (D-074) was approved on 2026-11-01 (D-075) and merged via PR #16: skills.js / tactics.js / status.js, schema 10 (imports 0–9). v0.8.1 「무기」 next on the user's instruction; never merge a release candidate before the user plays and approves it.
v0.8 「전술과 무기」 was approved as a direction on 2026-10-28 06:24 KST (D-073, docs/v0.8.0/GAMEPLAY_DESIGN.md, all recommended answers). Branch feature/v0.8-tactics-and-arms: v0.8.0 「전술」 — three skills per hero, four status effects, tools (throwables, ally use, bag 8), class matchups, ACT I–II re-tune to the same win rates; v0.8.1 「무기」 — regional/elite gear, revisiting towns, gear growth, treasures and hidden objectives. The catalog is src/data/catalog-v08.js (docs/v0.8.0/ITEM_CATALOG.md); art work pack E (102 icons, docs/v0.8.0/art/item-work-pack) is with the user. Never merge before the user plays and approves the release candidate.

## Current v0.7.1 entry (merged)
v0.7.0 is merged (PR #14 → 81f11d3, approved 2026-10-27 06:16 KST, D-070). v0.7.1 The Three Banners (ACT II complete, M13–M14; D-071) was approved by the user on 2026-10-27 18:34 KST with one fix (music Mute / BGM 0 / Music Pause now fully silent, D-072) and merged via PR #15. Never merge a future release candidate before the user plays and approves it. ACT III and awakening (Tier 3) start only on the user's instruction. Art work pack D (28 images) is with the user; until it arrives the pilgrim village uses a dusk-tinted Ashen Village painting and the new cast is procedural — never label those finished.
Read docs/v0.7.0 (ACT2B_DESIGN, IMPLEMENTATION_PLAN, RELEASE_NOTES), docs/v0.7.1 (RELEASE_NOTES, DIALOGUE_SCRIPT), docs/v0.6.0–v0.6.1 and the decisions D-055–D-075. D-031/032 stand: stable `eric` explores and fights, Aren is the non-deployable commander; Lia is the single strategist at her war table (D-043). Schema 9 imports 0–8 and nested stageStart; a schema-9 save from an earlier build loads as the current version; every load re-anchors the frontier to the hub of its story moment (hubFor → act2HubFor from M07, spatial only). Preserve the five ACT I heroes and recruits by roster (Thea, Dario, Ines; a recruit who left after M14 is kept in campaign.departed), ACT I and M07–M12 balance, v0.3.2 recovery/rewards/economy and M01–M03 EXP.
Tests target the newly built current version; historical HTML only generates migration/baseline fixtures. Execute units, balances, desktop/mobile/campaign/migration/offline/package/document checks. Physical devices/other engines/eviction unverified.
