import test from 'node:test';import assert from 'node:assert/strict';
import {HUBS} from '../src/data/frontier-data.js';
import {newGame} from '../src/core/game.js';import {enterHub,interactions,walkable,enterInterior,exitInterior,openCouncil} from '../src/core/frontier.js';import {drain} from './campaign-policy.mjs';
const hub=id=>{const s=newGame(17,null,id);enterHub(s);drain(s);return s;};
test('All doors share visual tile anchor / front-only approach / solid threshold / exact return',()=>{for(const id of [1,2]){const s=hub(id);for(const b of HUBS[s.frontier.hub].buildings.filter(b=>b.entrance)){
 const p=HUBS[s.frontier.hub].places.find(p=>p.buildingId===b.buildingId),e=b.entrance;
 assert.equal(p.entrance,e);assert.equal(p.x,e.tileX);assert.equal(p.y,e.tileY+1);assert.equal(walkable(s,e.tileX,e.tileY),false);
 for(const [x,y]of [[e.tileX,b.y-1],[b.x-1,e.tileY],[b.x+b.w,e.tileY],[e.tileX-1,p.y]]){s.frontier.x=x;s.frontier.y=y;assert.equal(interactions(s).some(n=>n.id===p.id),false);}
 s.frontier.x=p.x;s.frontier.y=p.y;assert.ok(walkable(s,p.x,p.y));assert.ok(interactions(s).some(n=>n.id===p.id));if(['weapon','item'].includes(p.action)){assert.ok(enterInterior(s,p.action));assert.ok(exitInterior(s));assert.deepEqual([s.frontier.x,s.frontier.y],[p.x,p.y]);}
 }}});
test('Existing council API opens briefing and preserves return coordinates; aftermath cannot depart',()=>{const s=hub(1),f=structuredClone(s.frontier);s.frontier.advisorPending=true;assert.ok(openCouncil(s));assert.equal(s.screen,'warroom');assert.equal(s.narrative.active.key,'raid');assert.deepEqual(s.frontier,f);drain(s);enterHub(s,{story:false});assert.deepEqual([s.frontier.x,s.frontier.y],[f.x,f.y]);s.frontier.phase='aftermath';assert.equal(openCouncil(s),false);});

test('Schema5 blocked doors and nested battle checkpoints recover spatial state without changing assets',async()=>{
 const {migrate}=await import('../src/persistence/save-manager.js');const {startBattle}=await import('../src/core/game.js');
 for(const schema of [4,5])for(const blocked of [false,true]){const s=hub(2);s.campaign.flags.keep_flag=true;s.campaign.bonds.erik_kai=true;s.screen='deployment';startBattle(s);const before=structuredClone(s);
 for(const target of [s,s.stageStart]){target.schema=schema;delete target.frontier.actorId;delete target.campaign.frontier.actorId;if(blocked){target.frontier.x=12;target.frontier.y=9;}target.campaign.frontier.x=5;target.campaign.frontier.y=5;}
 const fixed=migrate(s);assert.equal(fixed.schema,12);assert.equal(fixed.stageStart.schema,12);assert.equal(fixed.frontier.actorId,'eric');assert.ok(walkable(fixed,fixed.frontier.x,fixed.frontier.y));assert.deepEqual(fixed.units,before.units);assert.deepEqual(fixed.economy,before.economy);assert.deepEqual(fixed.campaign.flags,before.campaign.flags);assert.deepEqual(fixed.campaign.bonds,before.campaign.bonds);assert.deepEqual(fixed.campaign.heroes,before.campaign.heroes);assert.equal(fixed.rng,before.rng);assert.ok(walkable({frontier:fixed.campaign.frontier},fixed.campaign.frontier.x,fixed.campaign.frontier.y));}
});

test('Advisor authorization and error-only recovery share council API without remote/aftermath bypass',async()=>{
 const {recoverCouncil,interactNPC}=await import('../src/core/frontier.js');const s=hub(2);assert.equal(openCouncil(s),false);assert.ok(interactNPC(s,'advisor'));assert.equal(openCouncil(s),false);drain(s);assert.ok(openCouncil(s));drain(s);enterHub(s,{story:false});s.frontier.advisorPending=false;assert.ok(recoverCouncil(s));drain(s);enterHub(s,{story:false});s.frontier.x=3;s.frontier.y=7;assert.equal(recoverCouncil(s),false);s.frontier.x=7;s.frontier.y=7;s.frontier.phase='aftermath';assert.equal(recoverCouncil(s),false);
});
