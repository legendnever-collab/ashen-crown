import {MAP,ENEMIES,CIVILIANS,REINFORCEMENTS,TERRAIN} from './game-data.js';
const grid=rows=>rows.map(r=>r.split(''));
const patrol=(id,name,x,y,kind='bandit',hp=28)=>({id,name,x,y,kind,hp,atk:12,def:4,res:3,spd:6,mov:3,range:kind==='archer'?[2,3]:[1,1]});
export const MISSIONS={
 1:{id:1,title:'잿빛 마을의 습격',en:'The Ashen Village',map:MAP,enemies:ENEMIES,civilians:CIVILIANS,reinforcements:REINFORCEMENTS,threatTurn:5,par:8,objective:'주민 2명 구출 + 가르 격파',brief:'T3 북쪽 증원 · T5 주민 위협. 구조는 인접해서 행동 1회.'},
 2:{id:2,title:'숲길의 추격',en:'Forest Pursuit',map:grid(['fgrrrgrrrgff','fgrgrfrgrgff','fggffrffggff','ffgffrffgfff','fggrrrrggfff','fgrffrffrgff','fgfffrrffgff','grgggrrgggrg','grgggrrgggrg','ggggrrrrgggg']),enemies:[patrol('b1','탈영병',3,5),patrol('b2','굶주린 습격자',8,5),patrol('a1','숲의 사수',6,4,'archer',25),patrol('b3','후미 경계병',2,3),{...patrol('boss','도주 대장',5,3,'captain',54),mov:1}],civilians:[],reinforcements:[],threatTurn:99,par:8,turnLimit:8,objective:'도주 대장 생포 또는 추격 종료 (8턴)',brief:'도주 대장 HP 절반 이하 → 인접 장수의 생포. 북쪽 출구로 도망치기 전에 퇴로를 막으세요. 생포 실패도 진행 가능.'},
 3:{id:3,title:'무너진 다리',en:'The Broken Bridge',map:grid(['ggggrrrrgggg','ggggrrrrgggg','ggggrrrrgggg','xxxxxbbxxxxx','xxxxxbbxxxxx','ggggrrrrgggg','ggggrrrrgggg','grgggrrgggrg','grgggrrgggrg','ggggrrrrgggg']),enemies:[patrol('b1','추격 선봉',3,5),patrol('b2','추격병',8,5),patrol('a1','교량 사수',7,2,'archer',25),patrol('b3','북부 경계병',3,2),{...patrol('boss','추격 지휘관',6,1,'captain',55),mov:2}],civilians:[{id:'c1',name:'부상한 미라',x:4,y:6},{id:'c2',name:'토마스',x:7,y:6}],reinforcements:[patrol('r1','후방 추격병',0,9),patrol('r2','후방 사수',11,9,'archer',24)],threatTurn:3,par:10,turnLimit:10,objective:'10턴 안에 1명 이상 구조 + 생존 장수 전원 북쪽 철수',brief:'장수가 인접한 주민은 매 턴 다리를 건너 이동합니다. 인접 구출은 즉시 안전 이송. y≤2에 생존 장수 전원이 모이면 철수. 전원 구조에 도전하세요.'}
};
export const missionOf=s=>MISSIONS[s?.missionId||1];

// Preserve all old core coordinates for migration, add authored flanking regions.
for(const m of Object.values(MISSIONS)){const original=m.map.map(row=>[...row]);const width={1:16,2:18,3:14}[m.id],height={1:12,2:14,3:12}[m.id];m.map=Array.from({length:height},(_,y)=>Array.from({length:width},(_,x)=>{if(y<10&&x<12)return original[y][x];if(m.id===1)return x===13?'r':(y===2||y===6)&&x>13?'v':y===11?'f':'g';if(m.id===2)return x===13||y===11?'r':x===14&&y<8?'m':x>=16?'f':(x+y)%4===0?'f':'g';return y===3||y===4?'w':x===12?'r':'g';}));m.width=width;m.height=height;m.layers={terrain:m.map,collision:m.map.map(row=>row.map(t=>['x','w'].includes(t))),buildings:[],objects:[],actors:'units',effects:'feedback',events:'narrative'};if(m.id===1)m.layers.buildings=[{x:2,y:1,w:1,h:2,type:'residence',state:'burning'},{x:9,y:1,w:1,h:2,type:'residence',state:'burning'},{x:14,y:2,w:2,h:2,type:'depot',state:'burning'},{x:14,y:6,w:2,h:2,type:'residence',state:'intact'}];}
export const mapDimensions=s=>({width:missionOf(s).map[0].length,height:missionOf(s).map.length});

// Limited tactical supply sites; old core routes and victory deadlines stay intact.
MISSIONS[2].map[6][9]='h';
MISSIONS[3].map[5][5]='t';

// v0.4 ACT I missions are authored at full size; M01–03 data above stays unchanged.
const unit=(id,name,kind,x,y,stats={})=>({id,name,kind,x,y,hp:30,atk:13,def:5,res:3,spd:6,mov:3,range:kind==='archer'?[2,3]:[1,1],...stats});
const evidence=(id,name,type,x,y)=>({id,name,kind:'evidence',evidence:type,x,y});
function authored(m){m.map=grid(m.rows);delete m.rows;m.width=m.map[0].length;m.height=m.map.length;m.layers={terrain:m.map,collision:m.map.map(row=>row.map(t=>['x','w'].includes(t))),buildings:[],objects:[],actors:'units',effects:'feedback',events:'narrative'};m.objects=m.objects||[];m.waves=m.waves||[];m.reinforcements=m.reinforcements||[];m.civilians=m.civilians||[];return m;}
const zone=(cells)=>new Set(cells.map(([x,y])=>`${x},${y}`));
MISSIONS[4]=authored({id:4,title:'버려진 성채',en:'The Abandoned Fortress',
 rows:['xxxxxxxxxxxxxxxx','xkkkxkkkkkkxkkkx','xkkkxkkkkkkxkkkx','xkkkxxxkkxxxkkkx','xqkkkkkkkkkkkkqx','xxxkxxggggxxkxxx','xkkkxggggggxkkkx','xkkkkggghgggkkkx','xkkkxggggggxkkkx','xxkxxxggggxxxkxx','xxkxxqkkkkqxxkxx','grrrrrrrrrrrrrrg','ggggggggggmggggg','gggfffgggggfffgg'],
 enemies:[
  unit('boss','성채 병참관','captain',7,2,{hp:66,atk:16,def:7,res:4,spd:6,mov:0,alertMov:3}),
  unit('w1','성벽 사수','archer',1,4,{hp:26,atk:13,def:3,spd:7,mov:0}),
  unit('w2','성벽 사수','archer',14,4,{hp:26,atk:13,def:3,spd:7,mov:0}),
  unit('g1','성채 경비병','bandit',3,5),unit('g2','성채 경비병','bandit',12,5),
  unit('g3','관문 경비병','bandit',7,9,{hp:32}),unit('g4','보관실 경비병','bandit',8,3,{hp:32,def:6}),
  unit('t1','횃불 병참병','bandit',2,2,{hp:24,atk:11,def:3,mov:0,burns:'seal'}),
  unit('t2','횃불 병참병','bandit',13,2,{hp:24,atk:11,def:3,mov:0,burns:'orders'})],
 waves:[{turn:4,story:'4:reinforce',units:[unit('r1','지하 창고병','bandit',6,6,{hp:28}),unit('r2','지하 창고병','bandit',9,8,{hp:28})]}],
 objects:[evidence('e1','보급 장부','ledger',8,1),evidence('e2','봉인술 기록','seal',1,1),evidence('e3','이송 군령','orders',14,1)],
 deployZone:s=>{const base=[];for(let y=11;y<=13;y++)for(let x=0;x<16;x++)base.push([x,y]);if(s?.campaign?.flags?.mission_02_supply_route_discovered)base.push([2,8],[2,9],[2,10]);return zone(base);},
 deployments:{recommended:[[7,11],[5,12],[8,12],[7,13],[10,12]],assault:[[6,11],[4,11],[9,11],[7,12],[11,11]],defense:[[7,12],[5,13],[9,13],[7,13],[11,12]]},
 threatTurn:99,par:9,turnLimit:14,burnTurn:8,level:5,
 objective:'보급 장부 확보 + 성채 병참관 격파',
 brief:'증거 지점에 인접해 조사(행동 1회). TURN 7이 끝나면 살아 있는 횃불 병참병이 맡은 기록을 태웁니다. 보급 장부는 소각되지 않습니다. 제한 14턴.'});
// M05 The Lion of the Frontier: Baldrick's formation on the northern ridge, refugee wagons on the
// southern road. Victory A (formation broken) or B (road held through TURN 10).
MISSIONS[5]=authored({id:5,title:'국경의 사자',en:'The Lion of the Frontier',
 rows:['mmmmmmmrrrrmmmmmmm','mmmmmmgrrrrgmmmmmm','ffmmgggrrrrgggmmgg','fffgggggrrgggggmgg','ffffggggrrgggggggg','ffffggggrrgmmggggg','fffgggggrrgmmggggg','fffggggggrrggggggg','ffgggggggrrggggggg','ffggggggrrrggggggg','fgggggggrrgggggggg','rrrrrrrrrrrrrrrrrr','ggggggggggggggggff','fgggggggggggggggff'],
 enemies:[
  unit('boss','발드릭 로엔 · 검은 사자','lion',9,2,{hp:84,atk:18,def:9,res:5,spd:7,mov:3}),
  unit('f1','사자 기수','bearer',7,3,{hp:30,atk:9,def:5,res:3,spd:5,mov:2}),
  unit('f2','사자 기수','bearer',11,3,{hp:30,atk:9,def:5,res:3,spd:5,mov:2}),
  unit('s1','철왕관 창병','spear',6,4,{hp:30,atk:14,def:6,spd:5}),unit('s2','철왕관 창병','spear',12,4,{hp:30,atk:14,def:6,spd:5}),
  unit('s3','철왕관 창병','spear',8,5,{hp:30,atk:14,def:6,spd:5}),unit('s4','철왕관 창병','spear',10,6,{hp:30,atk:14,def:6,spd:5}),
  unit('a1','철왕관 궁수','archer',14,2,{hp:26,atk:13,def:3,spd:7,mov:2})],
 civilians:[{id:'w1',name:'보급 마차',kind:'wagon',x:5,y:11,hp:34,def:4,res:4},{id:'w2',name:'보급 마차',kind:'wagon',x:12,y:11,hp:34,def:4,res:4}],
 waves:[{turn:4,story:'5:reinforce',units:[unit('c1','철왕관 기병','cavalry',17,7,{hp:30,atk:15,def:5,res:2,spd:9,mov:5,movementProfile:'cavalry'}),unit('c2','철왕관 기병','cavalry',17,8,{hp:30,atk:15,def:5,res:2,spd:9,mov:5,movementProfile:'cavalry'})]}],
 formation:{bearers:['f1','f2'],def:2,hit:10,charge:4,leash:2},
 deployZone:s=>{const base=[];for(let y=10;y<=13;y++)for(let x=1;x<17;x++)if(!(y===11&&(x===5||x===12)))base.push([x,y]);return zone(base);},
 deployments:{recommended:[[8,10],[6,12],[10,12],[8,12],[11,10]],assault:[[9,10],[7,10],[10,11],[8,11],[12,10]],defense:[[5,10],[7,12],[11,12],[6,12],[12,10]]},
 threatTurn:99,par:8,turnLimit:10,level:6,
 objective:'사자 대형 붕괴(기수 2명 격파 + 발드릭 HP 50% 이하) 또는 TURN 10까지 보급 마차 1대 이상 사수',
 brief:'사자 기수 옆의 적은 DEF+2·명중+10. 발드릭은 아군이 붙어 있지 않은 고립된 장수를 노립니다(피해+4). TURN 4에 동쪽에서 기병 2기가 마차를 노리고 진입합니다.'});
// M06 The Ashen Oath (ACT I finale): escort four refugees through the border gate, unseal the two
// seal stones before TURN 11 ends, then break out north. Phase rules live in core/mission-rules.js.
const sealObject=(id,name,kind,x,y,extra={})=>({id,name,kind,x,y,...extra});
MISSIONS[6]=authored({id:6,title:'재의 맹세',en:'The Ashen Oath',
 rows:['ffgggggrrrrgggggff','fggggggrrrrggggggf','ggggxgggrrgggxgggg','xrxxqxxxrrxxxqxxxx','ggggxggkrrkggxggmm','ggggggggrrgggggmmm','fgggggggrrgggggmkm','ffggggggrrgggggmmg','ffggfgggrrggfgggfg','fgggffggrrggffgggf','ggggggggrrgggggggg','ggvgggggrrggggvggg','gggggggrrrrggggggg','ggggggrrrrrrgggggg','fgggggggrrggggggff','ffggggggrrgggggfff'],
 enemies:[
  unit('boss','봉쇄 집행관','captain',9,1,{hp:72,atk:17,def:8,res:5,spd:6,mov:0,breakMov:3}),
  unit('k1','왕실 봉인대','bandit',6,4,{hp:30,atk:14,def:6,spd:5,mov:2}),unit('k2','왕실 봉인대','bandit',7,5,{hp:30,atk:14,def:6,spd:5,mov:2}),
  unit('k3','왕실 봉인대','bandit',10,5,{hp:30,atk:14,def:6,spd:5,mov:2}),unit('k4','왕실 봉인대','bandit',11,4,{hp:30,atk:14,def:6,spd:5,mov:2}),
  unit('a1','봉인대 궁수','archer',4,3,{hp:24,atk:13,def:3,spd:7,mov:0}),unit('a2','봉인대 궁수','archer',13,3,{hp:24,atk:13,def:3,spd:7,mov:0}),
  unit('beacon','감시탑 봉화','beacon',16,6,{hp:26,atk:0,def:3,res:3,spd:0,mov:0,range:[0,0]})],
 civilians:[{id:'p1',name:'피난민 노인',x:6,y:12,hp:30,def:3},{id:'p2',name:'부상한 피난민',x:8,y:13,hp:30,def:3,startHP:13},{id:'p3',name:'피난민 어머니',x:11,y:12,hp:30,def:3},{id:'p4',name:'부상한 소년',x:13,y:13,hp:30,def:3,startHP:14}],
 objects:[sealObject('seal1','봉인석','sealstone',7,4,{locked:true,progress:0}),sealObject('seal2','봉인석','sealstone',10,4,{locked:true,progress:0}),sealObject('lever','측면 관문 레버','lever',2,7),sealObject('sidegate','측면 관문','gate',1,3,{inert:true})],
 waves:[{trigger:'start',when:'reported',story:'6:inspector',units:[unit('i1','군령부 감찰관','bandit',14,5,{hp:32,atk:15,def:6,spd:6})]},
  {trigger:'phase2',story:'6:pursuers',units:[unit('r1','남쪽 추격대','bandit',0,15,{hp:28,atk:14,def:5,spd:6}),unit('r2','남쪽 추격대','bandit',17,15,{hp:28,atk:14,def:5,spd:6})]},
  {trigger:'phase3',unlessBeacon:true,story:'6:garrison',units:[unit('g1','관문 수비대','bandit',7,1,{hp:30,atk:14,def:6,spd:5}),unit('g2','관문 수비대','bandit',10,1,{hp:30,atk:14,def:6,spd:5})]}],
 deployZone:s=>{const base=[];for(let y=11;y<=15;y++)for(let x=1;x<17;x++)base.push([x,y]);return zone(base.filter(([x,y])=>!MISSIONS[6].civilians.some(c=>c.x===x&&c.y===y)));},
 deployments:{recommended:[[8,11],[5,13],[9,12],[10,13],[12,12]],assault:[[8,11],[7,11],[9,11],[10,11],[6,11]],defense:[[7,12],[5,12],[9,14],[10,12],[12,14]]},
 threatTurn:3,par:10,sealTurn:11,level:7,turnLimit:16,escortOnly:true,healCivilians:true,
 objective:'피난민 호위 → 봉인석 2개 해제(TURN 11 종료 전) → 봉쇄 집행관 격파 또는 생존 장수 전원 관문 북쪽 철수',
 brief:'장수가 인접한 피난민은 매 턴 관문 쪽으로 2칸 이동합니다(HP 절반 이하는 세인의 치유가 필요). 피난민 2명 통과 또는 TURN 5에 2단계: 봉인석에 인접해 해제(리아 1회, 다른 장수 2회 누적). 서쪽 레버는 측면 관문을 엽니다. 동쪽 봉화를 부수면 3단계 증원이 오지 않습니다.'});
// v0.6 ACT II (D-055 §3, Phase D; maps, numbers and names PROPOSED). M07 Northern Orders: an Iron Crown supply
// convoy of three wagons drives up the snowy road to Ironhold's gate while deserters ambush it; Thea's escort (AI
// allies) rides with it. Two wagons through the gate wins. M08 Canyon Defense: hold the grey canyon beside Baldrick's
// troops; the command order (hold the canyon / send a rescue squad to the rear village) is chosen before battle.
const ally=(id,name,look,x,y,stats={})=>({id,name,look,kind:'soldier',x,y,hp:34,atk:14,def:8,res:3,spd:5,mov:3,range:[1,1],...stats});
const deserter=(id,name,x,y,stats={})=>unit(id,name,'bandit',x,y,{hp:32,atk:15,def:6,res:3,spd:6,mov:3,movementProfile:'rogue',...stats});
MISSIONS[7]=authored({id:7,title:'북부의 군령',en:'Northern Orders',
 rows:['mmmmmmmnrrnmmmmmmm','mmmmmnnrrrrnnmmmmm','mffnnnnrrrrnnnnmmm','fffnnnnrrrrnnnnnmm','ffnnnnnrrrrnnnnnnm','fnnnnnnrrrrnnnnnnn','wwwwwwwiiiiwwwwiww','wwwwwwwiiiiwwwwiww','nnnnnnnrrrrnnnnnnf','nfnnnnnrrrrhnnnnff','ffnnnnnrrrrnnnnnnf','fnnnnnnrrrrnnnnnnn','nnnnnnnrrrrnnnnnnn','nnnnnnnrrrrnnnnnnn'],
 enemies:[
  deserter('boss','탈영병 대장',2,3,{kind:'captain',hp:60,atk:17,def:8,res:4,spd:7}),
  deserter('d1','탈영병',1,4),deserter('d2','탈영병',4,2),deserter('d3','탈영병',16,8),deserter('d4','탈영병',17,10),
  unit('a1','탈영 궁수','archer',16,2,{hp:26,atk:14,def:3,res:3,spd:7,mov:2,movementProfile:'rogue'}),unit('a2','탈영 궁수','archer',15,1,{hp:26,atk:14,def:3,res:3,spd:7,mov:2,movementProfile:'rogue'})],
 civilians:[{id:'w1',name:'보급 마차',kind:'wagon',x:8,y:12,hp:48,def:7,res:5},{id:'w2',name:'보급 마차',kind:'wagon',x:9,y:12,hp:48,def:7,res:5},{id:'w3',name:'보급 마차',kind:'wagon',x:8,y:13,hp:48,def:7,res:5}],
 allies:[ally('thea_escort','테아 · 수송 호위대장','thea',10,12,{kind:'cavalry',hp:40,atk:16,def:7,spd:9,mov:5,movementProfile:'cavalry'}),ally('ic1','철왕관 보병','ironInfantry',7,12),ally('ic2','철왕관 보병','ironInfantry',9,13)],
 waves:[{turn:3,story:'7:ambush',units:[deserter('r1','후미 습격병',0,13),deserter('r2','후미 습격병',17,13)]},{turn:5,story:'7:gatewave',units:[deserter('r3','성문 습격병',7,1),deserter('r4','성문 습격병',11,1)]}],
 capture:'boss',
 deployZone:s=>{const base=[];for(let y=10;y<=13;y++)for(let x=3;x<=14;x++)if(!MISSIONS[7].civilians.some(c=>c.x===x&&c.y===y)&&!MISSIONS[7].allies.some(a=>a.x===x&&a.y===y))base.push([x,y]);return zone(base);},
 deployments:{recommended:[[7,11],[10,11],[6,12],[11,12],[6,13],[11,13]],assault:[[7,10],[10,10],[6,11],[11,11],[7,11],[10,11]],defense:[[7,11],[10,11],[7,13],[10,13],[6,12],[11,12]]},
 threatTurn:2,par:9,turnLimit:14,level:8,deployLimit:6,convoyGoal:2,
 objective:'보급 마차 3대 중 2대를 북쪽 성문까지 호위 (마차 2대를 잃으면 패배)',
 brief:'마차는 TURN 2부터 매 턴 길을 따라 북쪽으로 2칸 갑니다. 옆에 적이 붙으면 1칸만 가고, 장수가 길을 막으면 못 지나갑니다. 탈영병은 눈길(이동 1)과 숲에 익숙합니다. 탈영병 대장은 HP 절반 이하에서 인접해 생포할 수 있습니다. TURN 3 후미, TURN 5 성문 앞 증원.'});
MISSIONS[8]=authored({id:8,title:'협곡 방어전',en:'Canyon Defense',
 rows:['xxxxxnnrrnnxxxxx','xxxxnnnrrnnnxxxx','xxxnnnnrrnnnnxxx','xxmmnnnrrnnnmmxx','xxmmxnnrrnnxmmxx','xxxxmnnrrnnmxxxx','xxxxnnnrrnnnxxxx','xxxnnnnrrnnnnxxx','xxnnnfnrrnfnnnxx','xxnnnnnrrnnnnnxx','xxmmxnnrrnnxmmxx','xxmmxxnrrnxxmmxx','xnnnnnnrrnnnnnnx','nnvvnnnrrnnnvvnn','nnvvnnnrrnnnvvnn','nnnnnnnrrnnnnnnn'],
 enemies:[
  unit('m1','용병 창병','spear',5,1,{hp:32,atk:15,def:7,res:3,spd:6}),unit('m2','용병 창병','spear',10,1,{hp:32,atk:15,def:7,res:3,spd:6}),
  unit('m3','용병 창병','spear',6,2,{hp:32,atk:15,def:7,res:3,spd:6}),unit('m4','용병 창병','spear',9,2,{hp:32,atk:15,def:7,res:3,spd:6}),
  unit('a1','용병 궁수','archer',4,2,{hp:26,atk:14,def:3,res:3,spd:7}),unit('a2','용병 궁수','archer',11,2,{hp:26,atk:14,def:3,res:3,spd:7})],
 civilians:[{id:'v1',name:'후위 마을 노인',x:2,y:13,hp:24,def:2},{id:'v2',name:'후위 마을 어머니',x:3,y:14,hp:24,def:2},{id:'v3',name:'후위 마을 소년',x:13,y:13,hp:24,def:2}],
 allies:[ally('baldrick','발드릭 로엔 · 검은 사자','lion',7,5,{kind:'lion',hp:84,atk:18,def:9,res:5,spd:7,post:{x:7,y:5},leash:1}),ally('ic1','철왕관 보병','ironInfantry',6,5,{post:{x:6,y:5},leash:1}),ally('ic2','철왕관 보병','ironInfantry',9,5,{post:{x:9,y:5},leash:1})],
 objects:[sealObject('rf1','낙석 장치','rockfall',4,5,{zone:[5,7,3,6]}),sealObject('rf2','낙석 장치','rockfall',11,5,{zone:[8,10,3,6]})],
 waves:[{turn:3,story:'8:wave',units:[unit('m5','용병 창병','spear',6,0,{hp:32,atk:15,def:7,res:3,spd:6}),unit('m6','용병 창병','spear',9,0,{hp:32,atk:15,def:7,res:3,spd:6}),unit('m7','용병 창병','spear',5,1,{hp:32,atk:15,def:7,res:3,spd:6}),unit('a3','용병 궁수','archer',8,0,{hp:26,atk:14,def:3,res:3,spd:7})]},
  {turn:7,story:'8:captain',units:[unit('boss','용병단장','captain',7,0,{hp:84,atk:19,def:9,res:5,spd:7,mov:3,holdUntil:8}),unit('g1','단장 호위병','spear',6,0,{hp:34,atk:16,def:8,res:3,spd:6}),unit('g2','단장 호위병','spear',9,0,{hp:34,atk:16,def:8,res:3,spd:6})]},
  {turn:6,raid:true,units:[unit('s1','용병 습격조','bandit',0,13,{hp:28,atk:15,def:5,res:3,spd:8,mov:4}),unit('s2','용병 습격조','bandit',0,15,{hp:28,atk:15,def:5,res:3,spd:8,mov:4}),unit('s3','용병 습격조','bandit',15,15,{hp:28,atk:15,def:5,res:3,spd:8,mov:4})]}],
 deployZone:s=>{const base=[];for(let y=6;y<=9;y++)for(let x=3;x<=12;x++)base.push([x,y]);for(let y=12;y<=13;y++)for(let x=4;x<=11;x++)base.push([x,y]);return zone(base.filter(([x,y])=>Number.isFinite(TERRAIN[MISSIONS[8].map[y][x]].cost)&&!MISSIONS[8].allies.some(a=>a.x===x&&a.y===y)));},
 deployments:{recommended:[[6,7],[9,7],[5,8],[10,8],[7,9],[8,9]],assault:[[5,6],[10,6],[6,7],[9,7],[7,7],[8,7]],defense:[[6,9],[9,9],[5,8],[10,8],[7,12],[8,12]]},
 threatTurn:6,par:9,turnLimit:10,level:9,deployLimit:6,breachRow:12,orderTurn:6,
 objective:'TURN 10까지 협곡 사수 또는 TURN 7에 오는 용병단장 격파 (북쪽 적이 12번째 줄 아래로 넘어오면 패배)',
 brief:'위쪽 목은 발드릭의 병사가 지킵니다. 양쪽 벼랑의 낙석 장치(한 번씩)를 작동하면 위쪽 목 앞의 적에게 큰 피해를 줍니다. 출전 전에 사령부 명령(협곡 사수 / 후위 마을 구출조)을 정합니다. TURN 3 북쪽 2진, TURN 6 남쪽 습격조, TURN 7 용병단장과 호위병 도착(TURN 8까지 입구 사수).'});
// v0.6.1 ACT II (D-055 §3, D-067; maps, numbers and names PROPOSED). M09 The Free City: raiders strike Velmar's market
// square on the day the lords' delegates meet; escort the three delegates into the council hall (rescue) while assassins
// on the rooftops hunt them; the assassin leader can be taken alive. M10 Two Lords' War: Lord Oswin (blue-white) and
// Lord Brennan (orange) fight over the village between their camps; before battle the legion supports one of them or
// tries to mediate (capture both commanders).
const raider9=(id,x,y,stats={})=>unit(id,'벨마르 습격대','spear',x,y,{hp:32,atk:15,def:6,res:3,spd:7,mov:3,...stats});
const assassin9=(id,name,x,y,stats={})=>unit(id,name,'assassin',x,y,{hp:28,atk:17,def:4,res:4,spd:10,mov:5,movementProfile:'rogue',hunter:true,...stats});
MISSIONS[9]=authored({id:9,title:'자유의 도시',en:'The Free City',
 rows:['wwrxxxxkkkkxxxxxxx','wwrooolkkkkloooolx','wwrooolkkkkloooolx','wwrooolrrrrloooolx','bbrooorrrrrroooolx','bbrlxxrrrrrrxxxllx','wwrxxxrxrrxrxxxxlx','wwrxxxrrxxrrxxxxlx','wwrooorrrrrroooolx','wwrooorrrrrroooolx','wwrooolrrrrloooolx','wwrlllrrrrrrlllllx','wwrrhrrrrrrrrrrrlx','wwrrrrrrrrrrrrrrrx'],
 enemies:[
  assassin9('h1','자객',4,2),assassin9('h2','자객',13,9),
  raider9('m1',7,3),raider9('m2',10,3),raider9('m3',13,4),
  unit('a1','습격대 궁수','archer',3,9,{hp:26,atk:14,def:3,res:3,spd:7,mov:3}),unit('a2','습격대 궁수','archer',14,1,{hp:26,atk:14,def:3,res:3,spd:7,mov:3})],
 civilians:[{id:'v1',name:'청백 깃발 대표',look:'councillor',x:6,y:5,hp:30,def:3,res:3},{id:'v2',name:'주황 깃발 대표',look:'councillor',x:11,y:5,hp:30,def:3,res:3},{id:'v3',name:'항구 의원',look:'councillor',x:8,y:4,hp:30,def:3,res:3}],
 allies:[ally('dario_blade','다리오 · 용병 검사','dario',16,8,{kind:'swordsman',hp:40,atk:17,def:6,spd:10,mov:4,post:{x:13,y:7},leash:3}),ally('vg1','항구 경비병','guard',2,8,{post:{x:2,y:6},leash:2}),ally('vg2','항구 경비병','guard',2,10,{post:{x:2,y:9},leash:2})],
 waves:[{turn:3,story:'9:harbor',units:[raider9('s1',0,4),raider9('s2',1,5)]},{turn:5,story:'9:alley',units:[assassin9('boss','그림자 자객 우두머리',16,1,{kind:'captain',hp:60,atk:18,def:6,res:5,spd:11,mov:4}),assassin9('h3','자객',15,1),raider9('s3',16,2)]}],
 capture:'boss',
 deployZone:s=>{const base=[];for(let y=11;y<=13;y++)for(let x=3;x<=15;x++)base.push([x,y]);return zone(base.filter(([x,y])=>Number.isFinite(TERRAIN[MISSIONS[9].map[y][x]].cost)));},
 deployments:{recommended:[[7,11],[10,11],[6,12],[11,12],[8,12],[9,12]],assault:[[7,11],[10,11],[8,11],[9,11],[6,11],[11,11]],defense:[[7,12],[10,12],[5,12],[12,12],[8,13],[9,13]]},
 threatTurn:3,par:8,turnLimit:10,level:9,deployLimit:6,
 objective:'의회 대표 3명을 의회 회관으로 피신(인접해 구출) · 2명 이상 잃으면 패배 · TURN 5에 나타나는 그림자 자객 우두머리 격파·생포 또는 TURN 10까지 버티면 승리',
 brief:'대표 곁에서 구출하면 회관 안으로 피신합니다. 자객은 지붕(이동 2, 방어 +2, 활 사거리 +1)을 타고 대표만 노립니다. 일반 습격대는 TURN 3부터 대표를 노립니다. TURN 3 항구 부두, TURN 5 동쪽 골목에 우두머리와 증원. 우두머리는 HP 절반 이하에서 인접해 생포할 수 있습니다.'});
const lord10=(id,side,x,y,stats={})=>unit(id,side==='a'?'청백 영주군':'주황 영주군','spear',x,y,{hp:34,atk:16,def:8,res:3,spd:6,mov:3,faction:side,look:side==='a'?'lordA':'lordB',...stats});
const lordBow10=(id,side,x,y)=>unit(id,side==='a'?'청백 궁병':'주황 궁병','archer',x,y,{hp:28,atk:15,def:4,res:3,spd:7,mov:3,faction:side,look:side==='a'?'lordA':'lordB'});
MISSIONS[10]=authored({id:10,title:'두 영주의 전쟁',en:"Two Lords' War",
 rows:['ggggxxxxrrxxxxggsw','ggggxttttttttxggsw','gffgxttttttttxggsw','gffgxxxxrrxxxxggsw','ggggggggrrggggffsw','gggggggxrrxgggffsw','ggggggvvrrvvggffsw','rrhrrrrrrrggggggsw','rrrrrrrrrrggggggsw','ggggggvvrrvvggffsw','gggggggxrrxgggffsw','ggggggggrrggggffsw','gffgxxxxrrxxxxggsw','gffgxttttttttxggsw','ggggxttttttttxggsw','ggggxxxxrrxxxxggsw'],
 enemies:[
  lord10('boss','a',8,1,{name:'오스윈 경 · 청백 깃발',kind:'captain',hp:120,atk:20,def:10,res:5,spd:7,holdUntil:5}),
  lord10('lg1','a',8,2,{name:'청백 친위대',hp:40,def:11}),lord10('lg2','a',9,2,{name:'청백 친위대',hp:40,def:11}),
  lord10('la1','a',6,2),lord10('la2','a',11,2),lordBow10('la3','a',9,3),lord10('la4','a',12,4),lord10('la7','a',7,1),
  lord10('boss2','b',9,14,{name:'브레넌 경 · 주황 깃발',kind:'captain',hp:120,atk:20,def:10,res:5,spd:7,holdUntil:5}),
  lord10('lg3','b',8,13,{name:'주황 친위대',hp:40,def:11}),lord10('lg4','b',9,13,{name:'주황 친위대',hp:40,def:11}),
  lord10('lb1','b',6,13),lord10('lb2','b',11,13),lordBow10('lb3','b',8,12),lord10('lb4','b',5,11),lord10('lb7','b',10,14)],
 civilians:[{id:'v1',name:'마을 노인',x:6,y:7,hp:26,def:2},{id:'v2',name:'마을 아이',look:'child',x:11,y:8,hp:22,def:1},{id:'v3',name:'방앗간 주인',x:7,y:9,hp:26,def:2}],
 allies:[ally('dario_blade','다리오 · 용병 검사','dario',2,5,{kind:'swordsman',hp:42,atk:18,def:6,spd:10,mov:4})],
 waves:[{turn:4,story:'10:reinforce',units:[lord10('la5','a',8,0),lord10('la6','a',9,0),lord10('lb5','b',8,15),lord10('lb6','b',9,15)]}],
 capture:['boss','boss2'],
 deployZone:s=>{const base=[];for(let y=4;y<=11;y++)for(let x=0;x<=3;x++)base.push([x,y]);return zone(base.filter(([x,y])=>Number.isFinite(TERRAIN[MISSIONS[10].map[y][x]].cost)&&!(x===2&&y===5)));},
 deployments:{recommended:[[3,7],[3,8],[2,6],[2,9],[1,7],[1,8]],assault:[[3,7],[3,8],[3,6],[3,9],[2,7],[2,8]],defense:[[2,7],[2,8],[1,6],[1,9],[0,7],[0,8]]},
 threatTurn:5,par:10,turnLimit:12,level:10,deployLimit:6,stanceChoice:true,
 objective:'출전 전 선택 — 지원: 상대 영주 지휘관 격파·생포 / 중재: 두 지휘관 모두 생포(생포한 쪽 군은 물러남) · TURN 12 안에',
 brief:'두 영주군은 서로도 싸웁니다. 지원을 고르면 그 영주군이 동맹군이 되고, 그 영주는 쓰러지지 않습니다. 중재는 두 지휘관을 HP 절반 이하에서 인접해 생포해야 하며, 한 명이라도 쓰러뜨리면 중재는 실패합니다(전투는 두 지휘관이 모두 쓰러지면 끝납니다). TURN 5부터 병사들이 마을 주민을 노립니다. TURN 4 양쪽 증원.'});
// v0.7.0 ACT II part 2 (D-068; maps, numbers and names PROPOSED). M11 The Flame Procession: Lucien's pilgrims walk the
// night valley road to the southern sanctuary (two tiles a turn in light, one in the dark); lighting the three braziers
// (search) lights the road; ash raiders hunt them from the dark. Ines and two Sacred Flame knights escort as allies.
const ashRaider=(id,x,y,stats={})=>unit(id,'재 약탈단','bandit',x,y,{hp:30,atk:16,def:5,res:3,spd:8,mov:4,movementProfile:'rogue',look:'ashRaider',...stats});
const ashBow=(id,x,y)=>unit(id,'재 약탈단 궁수','archer',x,y,{hp:26,atk:15,def:3,res:3,spd:8,mov:3,look:'ashRaider'});
MISSIONS[11]=authored({id:11,title:'성화의 행렬',en:'The Flame Procession',
 rows:['xxxxxxzzzzzxxxxxxx','mmffggzzzzzggffmmm','mfffggggrggggfffmm','ffffgggfrfgggfffff','fffgggggrgggggffff','ffggggfgrgfggggfff','fggggffgrgffggggff','ggggggggrggggggggg','fgggfgggrgggfggggf','ffggggggrgggggggff','mffgggggrggggggffm','mmfgggggrgggggfmmm','mmffggggrggggffmmm','mmmfggggrggggfmmmm'],
 enemies:[ashRaider('r1',2,6),ashRaider('r2',15,5),ashRaider('r3',3,3),ashRaider('r4',14,8),ashBow('a1',13,3),ashBow('a2',4,8)],
 civilians:[{id:'p1',name:'순례자 노사제',look:'pilgrim',kind:'pilgrim',x:8,y:10,hp:26,def:3,res:4},{id:'p2',name:'순례자',look:'pilgrim',kind:'pilgrim',x:8,y:11,hp:26,def:3,res:3},{id:'p3',name:'순례자 어머니',look:'pilgrim',kind:'pilgrim',x:8,y:12,hp:26,def:3,res:3},{id:'p4',name:'순례자 소년',look:'pilgrim',kind:'pilgrim',x:8,y:13,hp:24,def:2,res:3}],
 allies:[ally('ines_warden','이네스 · 순례 수호자','ines',9,11,{kind:'warden',hp:44,atk:17,def:10,res:7,spd:6,mov:3,sanctuaryAura:true}),ally('fk1','성화 기사','flameKnight',7,11,{hp:38,atk:16,def:9,res:5}),ally('fk2','성화 기사','flameKnight',9,13,{hp:38,atk:16,def:9,res:5})],
 objects:[sealObject('br1','길가 화로','brazier',7,10),sealObject('br2','길가 화로','brazier',9,7),sealObject('br3','길가 화로','brazier',7,4)],
 waves:[{turn:3,story:'11:wave',units:[ashRaider('r5',4,13),ashRaider('r6',13,12)]},{turn:5,story:'11:flank',units:[ashRaider('r7',0,7),ashRaider('r8',17,7),ashBow('a3',0,9)]},
  {turn:7,story:'11:captain',units:[ashRaider('boss',15,2,{name:'재 약탈단 두목',kind:'captain',hp:72,atk:19,def:8,res:5,spd:9,mov:4}),ashRaider('r9',14,1),ashRaider('r10',1,2)]}],
 night:{radius:2,fixed:[[6,1],[7,1],[8,1],[9,1],[10,1]]},sanctuaryRow:1,road:['r','z'],
 deployZone:s=>{const base=[];for(let y=10;y<=13;y++)for(let x=4;x<=12;x++)base.push([x,y]);const m=MISSIONS[11],taken=[...m.civilians,...m.allies,...m.objects];return zone(base.filter(([x,y])=>Number.isFinite(TERRAIN[m.map[y][x]].cost)&&!taken.some(u=>u.x===x&&u.y===y)));},
 deployments:{recommended:[[7,12],[9,12],[6,11],[10,11],[7,13],[10,13]],assault:[[7,12],[9,12],[6,10],[10,10],[6,11],[10,11]],defense:[[7,12],[9,12],[7,13],[10,12],[6,12],[10,13]]},
 threatTurn:2,par:9,turnLimit:12,level:10,deployLimit:6,arriveGoal:3,escortOnly:true,
 objective:'순례자 4명 중 3명을 성소(맨 위)까지 호위 또는 TURN 12 새벽까지 버팀 · 순례자 2명 이상 잃으면 패배',
 brief:'순례자는 TURN 2부터 길을 따라 성소로 걷습니다. 빛 안에서는 2칸, 어둠에서는 1칸. 적이 곁에 붙거나 장수가 길을 막으면 멈춥니다. 길가 화로 3개에 인접해 조사하면 불이 켜져 반경 2칸이 밝아집니다. 빛 안의 아군은 명중 +10, 빛 밖의 대상을 노리면 명중 −15. 빛 안의 순례자는 아군 턴마다 HP +5. TURN 3 아래쪽, TURN 5 양옆 숲, TURN 7 북동쪽 숲에 두목.'});
// M12 The Silent Monastery: sneak into the Order's monastery archive. Quiet guards watch ahead of them and turn in a
// fixed order; a hero seen raises suspicion, a second sighting or noise rings the bell (alarm: guards wake, three come
// from the dormitory, and the abbot burns every record not yet secured three turns later).
const monk=(id,x,y,facing,turns,stats={})=>unit(id,'수도원 경비','spear',x,y,{hp:40,atk:16,def:8,res:4,spd:7,mov:0,alertMov:3,look:'monasteryGuard',watch:true,facing,turns,...stats});
MISSIONS[12]=authored({id:12,title:'침묵의 수도원',en:'The Silent Monastery',
 rows:['xxxxxxxxxxxxxxxxxx','xkkkkkxkkkkxkkkkkx','xkkkkkxkkkkxkkkkkx','xkkkkkxkkkkxkkkkkx','xxxkxxxxkkxxxxkxxx','xkkkkkkkkkkkkkkkkx','xkkxkggggggggkxkkx','xkkkkggggggggkkkkx','xkkxkggggggggkxkkx','xkkxkkkkkkkkkkxkkx','xxxxxxxxkkxxxxxxxx','gggfggggrrggggfggg','ggffgggrrrrgggffgg','gfffgggrrrrgggfffg'],
 enemies:[
  monk('g1',8,9,'down',['down','left','up','right']),monk('g2',5,7,'right',['right','down','left','up']),monk('g3',12,7,'left',['left','up','right','down']),
  monk('g4',3,5,'right',['right','down']),monk('g5',14,5,'left',['left','down']),monk('g6',3,3,'down',['down','right']),monk('g7',14,2,'down',['down','left']),
  unit('boss','침묵의 원장','captain',2,2,{hp:84,atk:19,def:8,res:7,spd:6,mov:0,alertMov:3,look:'abbot'})],
 objects:[evidence('rec_ledger','장부 기록','ledger',1,1),evidence('rec_seal','봉인술 연구','seal',16,1),evidence('rec_roster','교단 명부','roster',8,1)],
 waves:[{turn:99,alarm:true,story:'12:dorm',units:[monk('w1',1,7,'right',[],{awake:true,mov:3}),monk('w2',2,8,'right',[],{awake:true,mov:3}),monk('w3',1,9,'up',[],{awake:true,mov:3})]}],
 capture:'boss',stealth:true,burnDelay:3,
 deployZone:s=>{const base=[];for(let y=11;y<=13;y++)for(let x=0;x<18;x++)base.push([x,y]);return zone(base.filter(([x,y])=>Number.isFinite(TERRAIN[MISSIONS[12].map[y][x]].cost)));},
 deployments:{recommended:[[8,11],[9,11],[7,12],[10,12],[8,12],[9,12]],assault:[[8,11],[9,11],[7,11],[10,11],[8,12],[9,12]],defense:[[7,12],[10,12],[8,13],[9,13],[6,12],[11,12]]},
 threatTurn:99,par:10,turnLimit:14,level:11,deployLimit:6,
 objective:'장부 기록 확보(인접해 조사) + 침묵의 원장 격파·생포 · 장부 기록이 불타거나 TURN 14를 넘기면 패배',
 brief:'경비는 바라보는 방향 앞 2칸과 앞 대각선 2칸을 감시하고, 적 턴마다 정해진 순서로 돌아섭니다(붉은 칸). 적 턴이 시작될 때 감시 칸에 장수가 있으면 의심(감시 3칸), 한 번 더 들키거나 경비를 한 번에 쓰러뜨리지 못하면 종이 울립니다(경보). 경보가 울리면 경비가 모두 움직이고 숙소에서 셋이 나오며, 3턴 뒤 원장이 확보하지 못한 기록을 태웁니다. 감시 밖에서 조용한 경비를 치면 기습(명중 +30, 피해 +5). 원장은 HP 절반 이하에서 인접해 생포할 수 있습니다.'});
// v0.7.1 ACT II part 2 (D-068 §3/§6, D-071; maps, numbers and names PROPOSED). M13 The Black Lion's Decision: Cassian
// orders Baldrick to break up the legion's refugee camp; his lion formation marches on the tents. Erik (and Thea, once)
// can persuade him instead of attacking; resolve from ACT I–II choices and the battle decides whether he halts his army.
const lion13=(id,name,kind,x,y,look,stats={})=>unit(id,name,kind,x,y,{look,...stats});
MISSIONS[13]=authored({id:13,title:'검은 사자의 결단',en:"The Black Lion's Decision",
 rows:['mmmmffgggrrgggffmm','mmffggggrrrrggggfm','mfgggggrrrrrrgggff','ffgggfggrrrrgfgggf','fggggggggrrggggggg','gggxxgggrrrggxxggg','gggxxggrrrrgggxggg','ggggggrrggrrgggggg','gfgggrrggggrrggfgg','ffggrrggvvggrrggff','fggrrgvvvvvvggrrgf','ggrrgvvvhhvvvggrrg','grrggvvvvvvvvgggrr','rrggggvvvvvvggggrr'],
 enemies:[
  lion13('boss','발드릭 로엔 · 검은 사자','lion',9,2,'lion',{hp:120,atk:21,def:12,res:7,spd:7,mov:3}),
  lion13('f1','사자 기수','bearer',7,3,'bearer',{hp:44,atk:12,def:9,res:6,spd:5,mov:2}),lion13('f2','사자 기수','bearer',11,3,'bearer',{hp:44,atk:12,def:9,res:6,spd:5,mov:2}),lion13('f3','사자 기수','bearer',9,4,'bearer',{hp:44,atk:12,def:9,res:6,spd:5,mov:2}),
  lion13('s1','철왕관 창병','spear',6,4,'ironSpear',{hp:36,atk:17,def:8,res:3,spd:6}),lion13('s2','철왕관 창병','spear',12,4,'ironSpear',{hp:36,atk:17,def:8,res:3,spd:6}),
  lion13('s3','철왕관 창병','spear',8,5,'ironSpear',{hp:36,atk:17,def:8,res:3,spd:6}),lion13('s4','철왕관 창병','spear',10,5,'ironSpear',{hp:36,atk:17,def:8,res:3,spd:6}),
  lion13('a1','철왕관 궁수','archer',4,2,'ironArcher',{hp:28,atk:16,def:4,res:3,spd:7}),lion13('a2','철왕관 궁수','archer',14,2,'ironArcher',{hp:28,atk:16,def:4,res:3,spd:7})],
 civilians:[{id:'v1',name:'피난민 노인',x:6,y:11,hp:26,def:2},{id:'v2',name:'피난민 어머니',x:11,y:11,hp:26,def:2},{id:'v3',name:'피난민 아이',look:'child',x:7,y:12,hp:22,def:1},{id:'v4',name:'맹세하지 않은 순례자',look:'pilgrim',x:10,y:12,hp:26,def:2}],
 waves:[{turn:3,story:'13:cavalry',units:[lion13('c1','철왕관 기병','cavalry',0,6,'cavalry',{hp:34,atk:17,def:6,res:2,spd:9,mov:5,movementProfile:'cavalry'}),lion13('c2','철왕관 기병','cavalry',17,6,'cavalry',{hp:34,atk:17,def:6,res:2,spd:9,mov:5,movementProfile:'cavalry'})]},
  {turn:5,story:'13:reinforce',units:[lion13('s5','철왕관 창병','spear',8,0,'ironSpear',{hp:36,atk:17,def:8,res:3,spd:6}),lion13('s6','철왕관 창병','spear',11,0,'ironSpear',{hp:36,atk:17,def:8,res:3,spd:6})]}],
 formation:{bearers:['f1','f2','f3'],def:2,hit:10,charge:4,leash:2},persuade:{target:'boss',threshold:6},
 deployZone:s=>{const base=[];for(let y=7;y<=12;y++)for(let x=2;x<=15;x++)base.push([x,y]);const m=MISSIONS[13];return zone(base.filter(([x,y])=>Number.isFinite(TERRAIN[m.map[y][x]].cost)&&!m.civilians.some(c=>c.x===x&&c.y===y)));},
 deployments:{recommended:[[8,9],[9,9],[6,10],[11,10],[7,8],[10,8]],assault:[[8,8],[9,8],[7,8],[10,8],[6,9],[11,9]],defense:[[8,10],[9,10],[5,10],[12,10],[7,9],[10,9]]},
 threatTurn:4,par:10,turnLimit:12,level:11,deployLimit:6,lionHold:5,
 objective:'발드릭의 결단 6 (설득·선택·피난민 보호) 또는 TURN 5부터 사자 기수 3명 격파 + 발드릭 HP 50% 이하 또는 TURN 12까지 야영지 사수 · 피난민 2명 이상 잃으면 패배',
 brief:'에릭이 발드릭 곁에서 "설득"하면 결단이 1 오릅니다(턴마다 1번). 테아가 출전했다면 한 번 말을 건넬 수 있습니다. ACT I–II의 선택과, TURN 4부터 적 턴 동안 피난민이 다치지 않을 때마다(최대 2)도 결단이 오릅니다. 6이면 발드릭이 군을 멈춥니다. 발드릭은 TURN 5 전에는 대형이 무너져도 물러서지 않습니다. 사자 기수 곁의 적은 DEF+2·명중+10, 발드릭은 고립된 장수를 노립니다(피해+4). TURN 3 양쪽에서 기병, TURN 5 북쪽 증원.'});
// M14 The Broken Alliance: the three leaders meet at a ruined waystation outside the capital; masked raiders (the ledger
// cord) break in. Escort the leaders (allies) to the southern exit. On TURN 4 the banner that trusts the legion least
// turns on it: its leader leaves the field and its guards attack.
const guard14=(id,name,look,x,y,faction,stats={})=>ally(id,name,look,x,y,{faction,hp:40,atk:16,def:9,res:4,spd:6,mov:3,...stats});
const leader14=(id,name,look,x,y,faction)=>ally(id,name,look,x,y,{faction,kind:'leader',leader:true,hp:64,atk:17,def:8,res:6,spd:7,mov:3});
const masked=(id,x,y,stats={})=>unit(id,'가면 습격대','bandit',x,y,{hp:34,atk:18,def:7,res:4,spd:9,mov:4,movementProfile:'rogue',look:'maskedRaider',masked:true,...stats});
MISSIONS[14]=authored({id:14,title:'부서진 동맹',en:'The Broken Alliance',
 rows:['xxxxxxxkkkkxxxxxxx','xkkkkkkkkkkkkkkkkx','xkkkkkkkkkkkkkkkkx','xxxxxxkkkkkkxxxxxx','ggfgggrrrrrrgggfgg','gffggrrggggrrggffg','ggggrrgxxggrrggggg','gggrrggxxgggrrgggf','ffgrrggggggggrrggf','fggrrgggffgggrrggg','gggrrggggggggrrggg','ggggrrggggggrrgggg','gfgggrrrrrrrrgggfg','gggggggrrrrggggggg'],
 enemies:[masked('k1',0,5),masked('k2',17,5),masked('k3',1,9),masked('k4',16,9)],
 allies:[leader14('cassian','카시안 · 철왕관 통령','cassian',6,2,'iron'),leader14('leonora','레오노라 · 연맹 의장','leonora',9,2,'free'),leader14('lucien','루시안 · 성화 대사제','lucien',12,2,'flame'),
  guard14('ig1','철왕관 근위병','ironInfantry',5,1,'iron'),guard14('ig2','철왕관 근위병','ironInfantry',7,1,'iron'),guard14('fg1','연맹 경비병','guard',8,1,'free'),guard14('fg2','연맹 경비병','guard',10,1,'free'),
  guard14('lg1','성화 기사','flameKnight',11,1,'flame'),guard14('lg2','성화 기사','flameKnight',13,1,'flame')],
 waves:[{turn:2,story:'14:raid',units:[masked('k5',0,7),masked('k6',17,7),masked('k7',0,11,{look:'maskedRaider',kind:'archer',range:[2,3],hp:28,atk:16,def:4})]},
  {turn:4,units:[masked('k8',17,11),masked('k9',0,12)]},{turn:6,story:'14:exit',units:[masked('k10',3,13),masked('k11',14,13),masked('k12',17,8)]}],
 deployZone:s=>{const base=[];for(let y=4;y<=8;y++)for(let x=3;x<=14;x++)base.push([x,y]);return zone(base.filter(([x,y])=>Number.isFinite(TERRAIN[MISSIONS[14].map[y][x]].cost)));},
 deployments:{recommended:[[8,4],[9,4],[6,5],[11,5],[6,6],[10,6]],assault:[[7,4],[10,4],[5,5],[12,5],[8,5],[9,5]],defense:[[8,4],[9,4],[7,4],[10,4],[6,4],[11,4]]},
 threatTurn:99,par:9,turnLimit:12,level:12,deployLimit:6,exitRow:13,betrayTurn:4,
 objective:'세 지도자 중 둘 이상을 남쪽 출구(맨 아랫줄)까지 호위 · 지도자를 지킬 수 없게 되면(남은 지도자 둘 중 하나라도 쓰러짐) 패배 · TURN 12 안에',
 brief:'카시안·레오노라·루시안과 호위병이 동맹군으로 남쪽 출구로 물러납니다. 가면 습격대는 지도자를 노리고 양옆과 남쪽에서 계속 들어옵니다. TURN 4에 군단을 가장 믿지 않는 깃발(신뢰가 가장 낮은 세력)이 군단에 칼을 돌립니다: 그 지도자는 전장을 떠나고 호위병은 적이 됩니다.'});
// ---------- v0.9.0 ACT III 「왕관의 진실」 part 1 (D-079, docs/v0.9.0/ACT3_DESIGN.md §4; maps and numbers PROPOSED) ----------
// M15 The Lost Records: the capital's lower city at night. Three chancellery clerks carry the Ashen Night's record boxes out
// of the royal archive, each to its own gate (TURN 2 on, two tiles a turn); grey cloaks screen them. Knocking a clerk down
// secures its box. The royal watch stands neutral at three posts: fighting within two tiles of a watchman earns one warning,
// the second time the watch turns on the legion. The old archivist who guided the legion must live.
const cloak15=(id,x,y,stats={})=>unit(id,'회색 망토','bandit',x,y,{hp:64,atk:40,def:19,res:14,spd:26,mov:4,movementProfile:'rogue',look:'grayCloak',...stats});
const clerk15=(id,x,y,exit)=>unit(id,'재상부 서기','clerk',x,y,{hp:46,atk:0,def:14,res:12,spd:20,mov:2,look:'clerk',clerk:true,exit});
MISSIONS[15]=authored({id:15,title:'사라진 기록',en:'The Lost Records',
 rows:['xrxxxxxxxxxxxxxxxx','xrllllloxxolllllox','xrrrrrrrrrrrrrrrlx','rrrlxxxkkkkxxxrrrr','xolrxkkkkkkkkxrlox','xolrxkkkkkkkkxrlox','xllrxxxkkkkxxxrllx','xllrrrrrkkrrrrrllx','wwwbwwwwwbbwwwwbww','llvrllloollllrlvll','lollrlllllllrlllol','llllrrrrrrrrrrllll','lvllrllvvllllrllvl','llllrlllrrlllrllll'],
 enemies:[clerk15('c1',7,4,[1,0]),clerk15('c2',9,5,[0,3]),clerk15('c3',11,4,[17,3]),
  unit('cap','회색 망토 대장','captain',8,3,{hp:88,atk:44,def:22,res:18,spd:24,mov:4,movementProfile:'rogue',look:'grayCloak'}),
  cloak15('g1',3,7),cloak15('g2',10,7),cloak15('g3',15,7),cloak15('g4',5,2),cloak15('g5',12,2),
  cloak15('a1',1,4,{kind:'archer',range:[2,3],hp:52,atk:38,def:14,res:12,spd:24,movementProfile:'infantry'}),cloak15('a2',16,4,{kind:'archer',range:[2,3],hp:52,atk:38,def:14,res:12,spd:24,movementProfile:'infantry'})],
 civilians:[{id:'archivist',name:'늙은 기록관',look:'archivist',x:8,y:12,hp:30,def:3,res:4},
  {id:'w1',name:'왕도 경비대',look:'watchman',watch:true,x:2,y:10,hp:34,def:7,res:4},{id:'w2',name:'왕도 경비대',look:'watchman',watch:true,x:9,y:9,hp:34,def:7,res:4},{id:'w3',name:'왕도 경비대',look:'watchman',watch:true,x:15,y:10,hp:34,def:7,res:4}],
 waves:[{turn:3,story:'15:cloaks',units:[cloak15('g6',0,11),cloak15('g7',17,11)]},{turn:5,units:[cloak15('g8',0,9),cloak15('g9',17,9)]}],
 deployZone:s=>{const base=[];for(let y=11;y<=13;y++)for(let x=1;x<=16;x++)base.push([x,y]);return zone(base.filter(([x,y])=>Number.isFinite(TERRAIN[MISSIONS[15].map[y][x]].cost)&&!MISSIONS[15].civilians.some(c=>c.x===x&&c.y===y)));},
 deployments:{recommended:[[8,11],[9,11],[6,11],[11,11],[7,12],[10,12],[5,12],[12,12]],assault:[[8,11],[9,11],[3,11],[14,11],[7,11],[10,11],[4,12],[13,12]],defense:[[7,12],[9,12],[6,12],[10,11],[8,11],[7,11],[5,12],[11,12]]},
 threatTurn:3,par:9,turnLimit:12,level:13,deployLimit:7,watchRadius:2,clerkStart:1,
 objective:'서기 세 명의 행방을 모두 정하고 상자 2개 이상 확보 · 기록관 생존 · 상자 2개가 성문 밖으로 나가면 패배 · TURN 12 안에',
 brief:'재상부 서기 셋이 곧바로 각자 성문(북서·서·동)으로 달아납니다(턴마다 2칸). 서기를 쓰러뜨리면 상자를 확보합니다. 회색 망토가 길을 막고, TURN 3부터 기록관을 노립니다. 왕도 경비대(중립) 곁 2칸 안에서 싸우면 한 번 경고하고, 두 번째에는 경비대가 적이 됩니다.'});
// M16 The Forgotten Battlefield: a battlefield of the civil war that no one nearby remembers, under fog. Two chancellery
// memory harvesters draw on the ward stones; while one stands beside an unsearched stone, heroes near it lose MP each turn.
// Searching a stone shows an echo and clears the fog around it. Scavengers of the banner that betrayed the legion at the
// summit pick over the field; their captain challenges Erik to a duel on TURN 3. Recruits who left the legion (and Ines, if
// she never joined) wander in on TURN 2 as allies; alive at the end, they come back.
const SCAV16={iron:{name:'철왕관',soldier:'ironSpear',kind:'spear',archer:'ironArcher',captain:'ironInfantry'},free:{name:'연맹',soldier:'mercSpear',kind:'spear',archer:'pursuerArcher',captain:'lordA'},flame:{name:'성화',soldier:'flameKnight',kind:'bandit',archer:'fortArcher',captain:'flameKnight'}};
export const scavengerLook16=(f,role)=>SCAV16[f]?.[role]||SCAV16.iron[role];
const scav16=(id,x,y,role='soldier',stats={})=>unit(id,'배신한 깃발의 약탈대',role==='archer'?'archer':'spear',x,y,{hp:70,atk:42,def:21,res:12,spd:22,mov:3,scav:role,...(role==='archer'?{range:[2,3],hp:56,atk:40,def:15,spd:24}:{}),...stats});
const harvester16=(id,x,y,stone)=>unit(id,'기억 수확자','harvester',x,y,{hp:84,atk:40,def:16,res:40,spd:20,mov:2,range:[1,2],look:'harvester',stone});
const echo16=(id,name,x,y)=>({id,name,kind:'wardStone',x,y});
const return16=(id,look,x,y)=>ally(id,look==='thea'?'테아':look==='dario'?'다리오':'이네스',look,x,y,{returning:look,benched:true});
MISSIONS[16]=authored({id:16,title:'잊힌 전장',en:'The Forgotten Battlefield',weather:'fog',
 rows:['mmffgggggggggggffm','mfgggxggrrggxggggf','fggggxgrrggggxgggf','ggggggrrggfgggggfg','gggfggrggggggfgggg','ggxxgrrgggxxggggxg','gggggrggfggrrggggg','wwwwbwwwwwwbwwwwww','ggggrggfgggrgggfgg','gfggrgggggggrggggg','ggggrrggxxggrrgggf','fggggrrrrrrrrggggf','ggfggggrrrrggggfgg','gggggggrrrrggggggg'],
 enemies:[harvester16('h1',2,3,'st1'),harvester16('h2',14,3,'st2'),
  scav16('cap',9,4,'captain',{name:'배신한 깃발의 기사대장',kind:'captain',hp:110,atk:46,def:24,res:16,spd:24}),
  scav16('s1',6,5),scav16('s2',11,6),scav16('s3',8,2),scav16('s4',4,9),scav16('s5',13,9),scav16('a1',11,1,'archer'),scav16('a2',4,1,'archer')],
 objects:[echo16('st1','결계석',2,4),echo16('st2','결계석',14,4),echo16('st3','결계석',9,9)],
 allies:[return16('rthea','thea',0,11),return16('rdario','dario',0,12),return16('rines','ines',1,13)],
 waves:[{turn:4,story:'16:reinforce',units:[scav16('s6',8,0),scav16('s7',12,0)]},{turn:6,units:[scav16('s8',0,5),scav16('a3',17,5,'archer')]}],
 deployZone:s=>{const base=[];for(let y=10;y<=13;y++)for(let x=2;x<=15;x++)base.push([x,y]);return zone(base.filter(([x,y])=>Number.isFinite(TERRAIN[MISSIONS[16].map[y][x]].cost)&&!(MISSIONS[16].objects||[]).some(o=>o.x===x&&o.y===y)));},
 deployments:{recommended:[[8,11],[9,11],[5,11],[12,11],[7,12],[10,12],[4,12],[13,12]],assault:[[7,10],[10,10],[4,10],[12,10],[7,11],[10,11],[5,11],[11,11]],defense:[[8,12],[9,12],[6,12],[11,12],[7,13],[10,13],[5,13],[12,13]]},
 threatTurn:99,par:10,turnLimit:14,level:14,deployLimit:7,harvestMP:3,harvestRadius:3,clearRadius:2,duelTurn:3,returnTurn:2,
 objective:'기억 수확자 2명 격파 · TURN 14 안에 (돌아온 동료가 쓰러져도 패배는 아님)',
 brief:'안개: 활과 마법의 사거리 −1, 3칸 밖의 적은 정체가 보이지 않습니다. 결계석(3)을 조사하면 그 주위 2칸의 안개가 걷힙니다. 수확자가 조사하지 않은 결계석 곁에 있으면 턴마다 그 돌 3칸 안 장수의 MP가 3 줄어듭니다. TURN 3 기사대장이 에릭에게 일기토를 청합니다.'});
// v0.5.0 Phase E (D-047): promotion trials (101–105) and the repeatable Legion Drill (110). Non-story
// skirmishes after ACT I: never pushed into campaign.completed, no gold, permanent EXP (mission level 7).
// goal: survive (turn N ends with `protect` alive) · rout (all enemies down by `limit`) · reach (hero at row ≤ y)
// · gather (turn N ends with every `must` hero within `radius` of the trial hero). companions join the trial hero.
const skirmish=(id,kind,hero,m)=>{MISSIONS[id]=authored({id,skirmish:{kind,hero},threatTurn:99,level:7,par:m.limit,turnLimit:m.limit,...m});};
// (level is overridable per skirmish; the drill uses 9 so heroes below Lv 7 catch up faster)
skirmish(101,'trial','eric',{title:'수호의 시련',en:'Trial of the Guardian',
 rows:['ggggrrrrgggg','gfggrrrrggfg','ggggrrrrgggg','xxxxxrxrxxxx','xxxxxrxrxxxx','gggggrrrgggg','ggggggggfggg','gggvggggvggg','gggggggggggg','gggggggggggg'],
 enemies:[unit('b1','훈련 교관','bandit',4,0,{hp:30,atk:14,def:5,spd:6,mov:4}),unit('b2','훈련 교관','bandit',6,0,{hp:30,atk:14,def:5,spd:6,mov:4}),unit('b3','훈련 교관','bandit',8,0,{hp:30,atk:14,def:5,spd:6,mov:4}),unit('b4','훈련 교관','bandit',5,1,{hp:30,atk:14,def:5,spd:6,mov:4}),unit('b5','훈련 교관','bandit',7,1,{hp:30,atk:14,def:5,spd:6,mov:4})],
 civilians:[{id:'t1',name:'훈련병',kind:'trainee',x:4,y:8,hp:14,def:2,res:2},{id:'t2',name:'훈련병',kind:'trainee',x:8,y:8,hp:14,def:2,res:2}],
 deployments:{recommended:[[6,5],[0,9],[1,9],[10,9],[11,9]]},threatTurn:1,escortOnly:true,limit:5,
 goal:{type:'survive',turn:5,protect:['t1','t2'],hold:[6,5]},must:['eric'],
 objective:'TURN 5가 끝날 때까지 훈련병 2명 보호',brief:'방벽: 에릭 옆 칸의 적은 움직이지 못하고, 들어온 적도 멈춥니다. 두 관문 출구 사이에 서세요.'});
skirmish(102,'trial','elina',{title:'경계의 시련',en:'Trial of the Watch',
 rows:['gggggggggggg','gggfgggggfgg','gggggggggggg','ggggggrggggg','gggggrrrgggg','ggggrrrrrggg','gggggrrrgggg','ggggffffgggg','gggffffffggg','ggggffffgggg'],
 enemies:[unit('r1','습격 교관','bandit',1,0,{hp:26,atk:13,def:3,spd:7,mov:4}),unit('r2','습격 교관','bandit',4,0,{hp:26,atk:13,def:3,spd:7,mov:4}),unit('r3','습격 교관','bandit',7,0,{hp:26,atk:13,def:3,spd:7,mov:4}),unit('r4','습격 교관','bandit',10,0,{hp:26,atk:13,def:3,spd:7,mov:4}),unit('r5','습격 교관','bandit',6,1,{hp:26,atk:13,def:3,spd:7,mov:4})],
 deployments:{recommended:[[0,9],[5,8],[1,9],[10,9],[11,9]]},limit:9,
 goal:{type:'rout'},must:['elina'],
 objective:'TURN 9까지 습격 교관 5명 격파',brief:'경계 사격: 적 Phase에 사거리로 처음 들어온 적을 쏘고, 맞히면 그 자리에 묶습니다.'});
skirmish(103,'trial','lia',{title:'마력의 시련',en:'Trial of the Rune',
 rows:['gggggggggggg','ggfggvvggfgg','gggggvvggggg','gggggggggggg','ggggrrrrgggg','gggrrrrrrggg','ggggrrrrgggg','gggggggggggg','gggfggggfggg','gggggggggggg'],
 enemies:[unit('g1','룬 수호상','captain',3,1,{hp:64,atk:12,def:14,res:14,spd:3,mov:2}),unit('g2','룬 수호상','captain',6,0,{hp:64,atk:12,def:14,res:14,spd:3,mov:2}),unit('g3','룬 수호상','captain',8,1,{hp:64,atk:12,def:14,res:14,spd:3,mov:2}),unit('c1','룬 시종','bandit',4,2,{hp:22,atk:12,def:4,res:4,spd:5}),unit('c2','룬 시종','bandit',7,2,{hp:22,atk:12,def:4,res:4,spd:5})],
 deployments:{recommended:[[6,7],[0,9],[5,8],[10,9],[11,9]]},limit:7,companions:['eric'],
 goal:{type:'rout',targets:['g1','g2','g3']},must:['lia'],
 objective:'TURN 7까지 룬 수호상 3기 격파 (에릭 호위)',brief:'마력 지형: 십자 5칸 룬 위에서 아군 MAG +3, 적 RES −2. 수호상은 단단하지만 마법에 약해집니다.'});
skirmish(104,'trial','sain',{title:'구원의 시련',en:'Trial of the Ember',
 rows:['gggggggggggg','ggfgggggggfg','gggggggggggg','gggggggggggg','ggggggfggggg','gggggggggggg','gggggggggggg','ggggvttvgggg','gggggttggggg','gggggggggggg'],
 enemies:[unit('b1','추격 교관','bandit',2,0,{hp:34,atk:14,def:6,spd:6}),unit('b2','추격 교관','bandit',5,0,{hp:34,atk:14,def:6,spd:6}),unit('b3','추격 교관','bandit',9,0,{hp:34,atk:14,def:6,spd:6}),unit('b4','추격 교관','bandit',11,1,{hp:34,atk:14,def:6,spd:6}),unit('b5','추격 교관','bandit',0,1,{hp:34,atk:14,def:6,spd:6}),unit('a1','추격 궁수','archer',7,0,{hp:26,atk:13,def:3,spd:7})],
 deployments:{recommended:[[1,2],[0,9],[1,9],[6,8],[10,2]]},limit:5,companions:['eric','kai'],wounded:['eric','kai'],
 goal:{type:'gather',turn:5,radius:2},must:['sain','eric','kai'],
 objective:'TURN 5가 끝날 때 부상한 에릭·카이가 세인 곁(2칸 이내)에 생존',brief:'에릭과 카이는 부상으로 걷지 못합니다(HP 40%). 귀환의 기도로 2–4칸 떨어진 동료를 세인 곁으로 데려오세요.'});
skirmish(105,'trial','kai',{title:'그림자의 시련',en:'Trial of the Shadow',
 rows:['gggggggggggg','gggggggggggg','ggfggggggfgg','xxxxxxgxxxxx','gggggggggggg','ggfggggggfgg','gggggggggggg','gggggrrggggg','gggggrrggggg','gggggrrggggg'],
 enemies:[unit('s1','관문 파수꾼','captain',6,3,{hp:90,atk:10,def:15,res:10,spd:3,mov:1}),unit('w1','경비 교관','bandit',3,5,{hp:24,atk:12,def:4,spd:6,mov:2}),unit('w2','경비 교관','bandit',9,5,{hp:24,atk:12,def:4,spd:6,mov:2}),unit('w3','경비 교관','bandit',4,1,{hp:24,atk:12,def:4,spd:6,mov:2}),unit('w4','경비 궁수','archer',8,1,{hp:22,atk:12,def:3,spd:7,mov:1})],
 deployments:{recommended:[[0,9],[1,9],[11,9],[10,9],[6,8]]},limit:6,
 goal:{type:'reach',hero:'kai',row:0},must:['kai'],
 objective:'TURN 6까지 카이가 북쪽 끝(맨 윗줄) 도달',brief:'관문 틈은 파수꾼이 막고 있습니다. 그림자 교환으로 파수꾼과 자리를 바꿔 빠져나가세요.'});
skirmish(110,'drill',null,{title:'군단 훈련',en:'Legion Drill',level:9,
 rows:['ggggffggggggff','gfgggggrrggggf','ggggvgrrggvggg','ggggggrrgggggg','gffgggrrggggfg','gggggrrrrggggg','ggggrrggrrgggg','gggrrggggrrggg','ffggggfggggggf','gggvggggggvggg','gggggggggggggg','gggggggggggggg'],
 enemies:[unit('d1','모의전 보병','bandit',3,1,{hp:28,atk:14,def:6,spd:6}),unit('d2','모의전 보병','bandit',6,0,{hp:28,atk:14,def:6,spd:6}),unit('d3','모의전 보병','bandit',9,1,{hp:28,atk:14,def:6,spd:6}),unit('d4','모의전 보병','bandit',11,3,{hp:28,atk:14,def:6,spd:6}),unit('d5','모의전 보병','bandit',2,4,{hp:28,atk:14,def:6,spd:6}),unit('d6','모의전 궁수','archer',7,2,{hp:24,atk:13,def:3,spd:7}),unit('d7','모의전 궁수','archer',12,1,{hp:24,atk:13,def:3,spd:7}),unit('d8','모의전 대장','captain',8,0,{hp:40,atk:15,def:7,res:4,spd:6})],
 civilians:[{id:'q1',name:'보급병',kind:'trainee',x:1,y:6,hp:24,def:2,res:2},{id:'q2',name:'보급병',kind:'trainee',x:12,y:6,hp:24,def:2,res:2}],
 deployments:{recommended:[[6,10],[4,11],[7,11],[6,11],[9,10]]},threatTurn:4,limit:12,
 deployZone:s=>{const base=[];for(let y=9;y<=11;y++)for(let x=2;x<12;x++)base.push([x,y]);return zone(base);},
 goal:{type:'rout'},
 objective:'TURN 12까지 모의전 부대 8명 격파 (보급병 구출은 선택)',brief:'반복 가능한 훈련. 전투 경험과 잠재력 기록이 영구히 남습니다. 미션 레벨 7.'});
export const isSkirmish=id=>!!MISSIONS[id]?.skirmish;
export const LAST_MISSION=Math.max(...Object.keys(MISSIONS).map(Number).filter(id=>!MISSIONS[id].skirmish));
